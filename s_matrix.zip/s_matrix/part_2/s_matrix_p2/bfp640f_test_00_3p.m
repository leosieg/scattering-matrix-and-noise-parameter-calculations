% test program 
% transistor as three port
% common earth, earth free
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
clear all
close all
%
% frequency
freq = 1e9;
%
% spline with data for transistor common emitter
[s11,s12,s21,s22,cs11,cs12,cs22] = s2spl_N('BFP640F_S.txt','BFP640F_N.txt',freq);
%
display(' ')
display('===== two port parameters =====')
display(' ')
% 2 port transistor matrices common emitter
t2sp = [s11 s12
        s21 s22]
t2cs = [cs11 cs12
  conj(cs12) cs22]
%
display(' ')
display('===== three port parameters common earth =====')
display(' ')
% 3 port transistor matrix common earth
[t3sp,t3cs] = t2tot3ce_N(t2sp,t2cs)
%
sp_sum_row = [sum(t3sp(1,:)) sum(t3sp(2,:)) sum(t3sp(3,:))]
%
sp_sum_col = [sum(t3sp(:,1)) sum(t3sp(:,2)) sum(t3sp(:,3))]
%
cs_sum_row = [sum(t3cs(1,:)) sum(t3cs(2,:)) sum(t3cs(3,:))]
%
cs_sum_col = [sum(t3cs(:,1)) sum(t3cs(:,2)) sum(t3cs(:,3))]
%
% ========================================================
%
display(' ')
display('===== three port parameters earth free =====')
display(' ')
% 3 port transistor matrix earth free
[t3sp,t3cs] = t2tot3ef_N(t2sp,t2cs)
%
sp_sum_row = [sum(t3sp(1,:)) sum(t3sp(2,:)) sum(t3sp(3,:))]
%
sp_sum_col = [sum(t3sp(:,1)) sum(t3sp(:,2)) sum(t3sp(:,3))]
%
cs_sum_row = [sum(t3cs(1,:)) sum(t3cs(2,:)) sum(t3cs(3,:))]
%
cs_sum_col = [sum(t3cs(:,1)) sum(t3cs(:,2)) sum(t3cs(:,3))]

