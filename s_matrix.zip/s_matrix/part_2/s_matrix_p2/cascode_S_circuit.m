function [rsp11,rsp12,rsp21,rsp22] = cascode_S_circuit(freq,dsp)
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% cascode_S_cicuit(freq,dsp)
%
% freq = current frequency/Hz
%  dsp = display parameter
%        dsp == 1 display 
%
freq_N = length(freq);
%
% matrix adjustmens
rsp11 = zeros(1,freq_N);
rsp12 = zeros(1,freq_N);
rsp21 = zeros(1,freq_N);
rsp22 = zeros(1,freq_N);
%
[s11,s12,s21,s22] = s2spl_S('BFP640F_S.txt',freq);
%
q = 1;
%
while q <= freq_N
%
fq = freq(q);
%
% transistor
t2sp = [s11(q) s12(q)
        s21(q) s22(q)];
%
% 3 port transistor matrix
t3sp = t2tot3ce_S(t2sp)
%
% short z = 0 reflection coefficient
[gsp,gcs] = gamma_z(0);
%
% transistor short at port 1 == base/gate
% for common base/gate
rsp = Snpc_xy(t3sp,gsp,1,1,dsp);
%
% or direct
%rsp = Snpc_xy(t3sp,-1,1,1,dsp);
%
% because in result after connection 
% old port 2 collector new port 1 
% and 
% old port 3 emitter new port 2
% but it must be
% port 1 emitter, port 2 collector
% for common base
% we must use twice flip to get a matrix from
% [a b    to      [d c
%  c d]            b a]
%
rsp = flip(fliplr(rsp));
%
% cascode connection, collector/drain <---> emitter/source
rsp = Snpc_xy(t2sp,rsp,2,1,dsp);
%
% S parameters
rsp11(q) = rsp(1,1);
rsp12(q) = rsp(1,2);
rsp21(q) = rsp(2,1);
rsp22(q) = rsp(2,2);
%
q = q+1;
%
end
end
