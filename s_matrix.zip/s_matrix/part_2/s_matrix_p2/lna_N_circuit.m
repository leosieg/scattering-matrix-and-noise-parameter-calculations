function [rsp11,rsp12,rsp21,rsp22,rcs11,rcs12,rcs22] = lna_N_circuit(freq,dsp)
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% lna_N_cicuit(freq,dsp)
%
% freq = current frequency/Hz
%  dsp = display parameter
%        dsp == 1 display 
%
freq_N = length(freq);
%
% matrix adjustmens
rsp11 = zeros(1,freq_N);
rsp12 = zeros(1,freq_N);
rsp21 = zeros(1,freq_N);
rsp22 = zeros(1,freq_N);
%
rcs11 = zeros(1,freq_N);
rcs12 = zeros(1,freq_N);
rcs22 = zeros(1,freq_N);
%
c0 = 2.99792458e8;
% lambda/4 for freq = 1e9
l4 = c0/(4*1e9);
%
[s11,s12,s21,s22,cs11,cs12,cs22] = s2spl_N('BFP640F_S.txt','BFP640F_N.txt',freq);
%
q = 1;
%
while q <= freq_N
%
fq = freq(q);
%
% nomalized inductance, capacitance
[jwl,jwc] = jomegalc(fq);
%
% transistor
t2sp = [s11(q) s12(q)
       s21(q) s22(q)];
%
t2cs = [cs11(q) cs12(q)
  conj(cs12(q)) cs22(q)];	   
%
% reflection coefficient and noise from emitter inductor
[gsp,gcs] = gamma_z(jwl*0.5e-9);
%
% 3 port transistor matrix, common earth
[t3sp,t3cs] = t2tot3ce_N(t2sp,t2cs);
%
% transistor with emitter inductor
[rsp,rcs] = Nnpc_xy(t3sp,t3cs,gsp,gcs,3,1,dsp);
%
% reflection coefficient and noise from parallel admittance
% between base and collector
% for test purpose only
% in practice y -> 0
[gsp,gcs] = gamma_y(1/(1e6/50));
%
% 3 port transistor matrix with connected inductor, earth free
[t3sp,t3cs] = t2tot3ef_N(rsp,rcs);
%
% resistor between base and collector
[rsp,rcs] = Nnpc_xy(t3sp,t3cs,gsp,gcs,3,1,dsp);
%
% transistor with Le and parallel admittance
% change sign, 
% because different polarity earth free and common earth
t2sp = [rsp(1,1) -rsp(1,2)
       -rsp(2,1) rsp(2,2)];
%
t2cs = [rcs(1,1) -rcs(1,2)
       -rcs(2,1) rcs(2,2)];	  
%	  
% input lambda/4-line 78 Ohm
[lisp,lics] = line_s(78,l4,fq);
%
% input parallel L 
[Lisp,Lics] = y_parallel(1/(jwl*55.5e-9));
%
% output parallel y
[Yosp,Yocs] = y_parallel(1/(30/50+jwl*2e-9));
%
% output parallel C
[Cosp,Cocs] = y_parallel(jwc*0.5e-12);
%
% ouput lambda/4-line 38 Ohm
[losp,locs] = line_s(38,l4,fq);
%
% amplifier circuit
%
[rsp,rcs] = Nnpc_xy(lisp,lics,Lisp,Lics,2,1,dsp);
%
[rsp,rcs] = Nnpc_xy(rsp,rcs,t2sp,t2cs,2,1,dsp);
%
[rsp,rcs] = Nnpc_xy(rsp,rcs,Yosp,Yocs,2,1,dsp);
%
[rsp,rcs] = Nnpc_xy(rsp,rcs,Cosp,Cocs,2,1,dsp);
%
[rsp,rcs] = Nnpc_xy(rsp,rcs,losp,locs,2,1,dsp);
%
% S parameters
rsp11(q) = rsp(1,1);
rsp12(q) = rsp(1,2);
rsp21(q) = rsp(2,1);
rsp22(q) = rsp(2,2);
%
% noise wave matrix
rcs11(q) = rcs(1,1);
rcs12(q) = rcs(1,2);
rcs22(q) = rcs(2,2);
%
q = q+1;
%
end
end
