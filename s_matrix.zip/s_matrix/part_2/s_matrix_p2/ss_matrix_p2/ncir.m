function ncir(np,dsp,val)
%
% noise circles
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
% 
% ncir(np,dsp)
%
% np(1,1) = Fmin/dB
% np(2,1) = Rn/ohm
% np(3,1) = CN
% np(4,1) = Gopt
%     dsp = display paramter
%           'z' -> Smith chart z version
%			'y' -> Smith chart y version
%	  val =	noise circle F/Fmin distance/dB
%           example val = [0:0.5:3]
%
Fmin = np(1,1);
CN = np(3,1); 
Gopt = np(4,1);
%
% Schwarz inequality
Si = 10^(0.1*Fmin)-1-CN*(1-(abs(Gopt))^2);
%
valq = length(val);
%
% point density
pk = 200;
phi = linspace(0,2*pi,pk);
%
valsmith = [0 0.2 0.5 1 2 5];
%
% Smith chart z
if dsp == 'z' 
smith_z(valsmith) 
end
%
% Smith chart y
if dsp == 'y' 
smith_y(valsmith) 
end
%
axis equal
axis off
hold on
%
q = 1;
%
while q <= valq
%
n = Fmin*(10^(0.1*val(q))-1)/CN;
% 
% radius noise circle
rnc = sqrt(n*(1+n-(abs(Gopt))^2))/(1+n);
%
% center noise circle
cnc = Gopt/(1+n);
%
z = cnc + rnc*exp(1i*phi);
%
plot(real(z),imag(z),'-k','LineWidth',2)
%
q = q+1;
%
end
%
% Gopt
xg = real(Gopt);
yg = imag(Gopt);
%
plot(xg,yg,'ok','LineWidth',5)
%
h = text(xg,yg,'\Gamma_{opt}','FontSize',14,'color','k','FontWeight','bold');
set(h,'VerticalAlignment', 'bottom');
%
text(-1,1.1,'noise circles, \Delta F/F_{min} = 0.5dB','FontSize',14,'color','k','FontWeight','bold')
%
disp(['Schwarz inequality Si = ' num2str(Si,4)])
%
end
%
