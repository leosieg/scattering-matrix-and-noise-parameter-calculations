function [sp,cs] = line_s(Zl,ll,freq)
% 
% S-parameters
% ideal lossless line, series, unmatched
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% [sp,cs] = line_s(Zl,ll,freq)
% 
%      Zl = characteristic impedance/Ohm
%      ll = line length/m
%    freq = frequency/Hz current
%
c0 = 2.99792458e8;
bl = 2*pi*freq*ll/c0;
g = (Zl/50-1)/(Zl/50+1);
%
n = 1-g*g*exp(-1i*2*bl);
%
rho = g*(1-exp(-1i*2*bl))/n;
tau = exp(-1i*bl)*(1-g*g)/n;
%
sp = [rho tau
      tau rho];
%
cs = 0*(eye(2)-sp*sp')/4;	  	  
%
end