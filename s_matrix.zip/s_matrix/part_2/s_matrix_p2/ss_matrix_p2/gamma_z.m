function [gsp,gcs] = gamma_z(z)
% 
% reflection coefficient and noise wave
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% z_s(z)
%
% z = normalized impedance or with 1/ admittance
%
gsp = (z-1)/(z+1);
%
% noise wave matrix (passive n-port)
gcs = (1-abs(gsp)^2)/4;	  	  
%
end