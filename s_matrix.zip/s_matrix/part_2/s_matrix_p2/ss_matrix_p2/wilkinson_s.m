function [rsp,rcs] = wilkinson_s(l4_0,freq)
% 
% Wilkinson splitter
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% [rsp,rcs] = ws(l4_0,freq)
%
% l4_0 = lambda/4/m at design frequency
% freq = frequency/Hz current
% 
% 3-port splitter
[spx,csx] = p3sp;
%
% save 3-port splitter
psp = spx;
%
% lambda/4-line 70.71 Ohm
% at the design frequency
%
[spy,csy] = line_s(sqrt(2)*50,l4_0,freq);
%
rsp = Snpc_xy(spx,spy,2,1,0);
%
rsp = Snpc_xy(rsp,spy,2,1,0);
%
rsp = Snpc_xy(rsp,psp,2,1,0);
%
rsp = Snpc_xy(rsp,psp,2,1,0);
%
% Wilkinson resistor
[spy,csy] = z_series(100/50);
%
rsp = Snpc_xy(rsp,spy,3,1,0);
%
% S-paramters whole Wilkinson splitter
rsp = Snpc_x(rsp,3,5,0);
%
% noise wave matrix whole Wilkinson splitter (passive n-port)
rcs = (eye(3)-rsp*rsp')/4; 	  
%
end