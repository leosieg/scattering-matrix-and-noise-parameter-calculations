function z = F_CIR(Fmin,CN,Gopt,Fu,Fn,Rn)
%
% noise circle points
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
% 
%    z = F_CIR(Fmin,CN,Gopt,Fo,Fn,Rn)
%
% Fmin = minimum noise figure/dB
% Gopt = reflection coefficient for noise matching
%   CN = noise constant
%   Fu = upper noise figure/dB
%   Fn = number of circles between Fu-Fmin
%   Rn = number of radius 180/Rn
%
Goptm = abs(Gopt);
Gopta = angle(Gopt);
%
fi = Fmin*(1+(Fu/Fmin-1).*(0:Fn)'/Fn);
fii = pi*(-Rn:Rn)/Rn;
ni = (10.^(fi.*0.1)-10.^(Fmin.*0.1))./CN;
cfi = Goptm./(1+ni);
rfi = sqrt(ni.*(ni+1-Goptm.^2))./(1+ni);
fo = ones(size(fii))*Gopta;
z = cfi*exp(1i*fo)+rfi*exp(1i*fii);
end

