% ===========================================================
% S- and noise parameters computation of simple electrical networks
% ===========================================================
% Siegfried Martius
% Lehrstuhl fuer Hochfrequenztechnik
% Friedrich Alexander University
% Erlangen-Nuernberg
% Cauerstrasse 9
% D-91058 Erlangen
% GERMANY
% 
% siegfried.martius@fau.de
% www.lhft.de
%
% ===========================================================
% 
% F_CIR.m      noise circles
% F_G.m        noise figure, G unequal Gopt
% gamma_y.m    reflection coefficient, admittance, one port
% gamma_z.m        reflection coefficient, impedance, one port
% jomegalc.m   nomalized impedance, admittance
% line_p.m     ideal lossless line, parallel, end open or short
% line_s.m     ideal lossless line, series, unmatched
% ncir.m       noise circles
% ncirp.m      noise circles with paraboloid
% Nnpc_x.m     connection programm for two ports at n-port x,
%              signal and noise  
% Nnpc_xy.m    connection programm for one port of n-port x
%              with one port of n-port y,
%              signal and noise
% p3sp         3-port parallel splitter 
% s2spl_N.m    spline for data iteration, signal and noise
% s2spl_S.m    spline for data iteration, signal only
% smith_y.m    Smith chart, y-version
% smith_z.m    Smith chart, z-version
% Snpc_x.m     connection programm for two ports at n-port x,
%              signal only  
% Snpc_xy.m    connection programm for one port of n-port x
%              with one port of n-port y,
%              signal only 
% sskl.m       stability circle, load plane
% ssks.m       stability circle, source plane
% t2tot3ce_N   two port matrices signal and noise of common emitter/source
%              to three port matrices, common earth
% t2tot3ce_S   two port matrices signal only of common emitter/source
%              to three port matrices, common earth
% t2tot3ef_N   two port matrices signal and noise of common emitter/source
%              to three port matrices, earth free
% t2tot3ef_S   two port matrices signal only of common emitter/source
%              to three port matrices, earth free
% wikinson_s.m Wilkinson splitter 
% y_parallel.m normalized admittance parallel
% z_series.m   normalized impedance series
%
% ===========================================================			 