function [s11,s12,s21,s22,cs11,cs12,cs22] = s2spl_N(data_S,data_N,freq)
%
% data spline from txt(s2p) file for frequency analysis
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202403
% 
% [s11,s12,s21,s22,cs11,cs12.cs22] = sspl(data_S,data_N,freq)
%
%                           data_S = string *.txt S-parameters file
%                                    example 'BFP640F_S.txt'
%                           data_N = string *.txt noise parameters file
%                                    example 'BFP640F_N.txt'
%                             freq = frequency/Hz
%
% units data txt(s2p) file
% freq/GHz mag(s11) ang(s11) mag(s21) ang(s21) mag(s12) ang(s12) mag(s22) ang(s22)
%
freq_N = length(freq);
%
% read S parameters
fiS = fopen(data_S,'r');
Sp = fscanf(fiS,'%f');
fclose(fiS);
%
spl = length(Sp);
d_S = zeros(spl/9,9);
%
% here freq from table
d_S(:,1) = Sp(1:9:spl-8)*1e9;
%
d_S(:,2) = Sp(2:9:spl-7);
d_S(:,3) = Sp(3:9:spl-6);
d_S(:,4) = Sp(4:9:spl-5);
d_S(:,5) = Sp(5:9:spl-4);
d_S(:,6) = Sp(6:9:spl-3);
d_S(:,7) = Sp(7:9:spl-2);
d_S(:,8) = Sp(8:9:spl-1);
d_S(:,9) = Sp(9:9:spl);
%
q = 2;
%
d_sp = zeros(freq_N,9);
%
while q <= 9
%
d_sp(:,q) = spline(d_S(:,1),d_S(:,q),freq);
%
q = q+1;
end
%
s11 = d_sp(:,2).*exp(j*d_sp(:,3)*pi/180);
s21 = d_sp(:,4).*exp(j*d_sp(:,5)*pi/180);
s12 = d_sp(:,6).*exp(j*d_sp(:,7)*pi/180);
s22 = d_sp(:,8).*exp(j*d_sp(:,9)*pi/180);
%
% units data txt(s2p) file
% freq/GHz nfmin/dB mag(gopt) ang(gopt) rn(Rn/50
%
% read noise parameter
fiN = fopen(data_N,'r');
Np = fscanf(fiN,'%f');
fclose(fiN);
%
npl = length(Np);
d_N = zeros(npl/5,5);
%
% here freq from table
d_N(:,1) = Np(1:5:npl-4)*1e9;
%
d_N(:,2) = Np(2:5:npl-3);
d_N(:,3) = Np(3:5:npl-2);
d_N(:,4) = Np(4:5:npl-1);
d_N(:,5) = Np(5:5:npl);
%
q = 2;
%
d_np = zeros(freq_N,5);
%
while q <= 5
%
d_np(:,q) = spline(d_N(:,1),d_N(:,q),freq);
%
q = q+1;
end
%
Fmin = d_np(:,2);
Gopt = d_np(:,3).*exp(j*d_np(:,4)*pi/180);
Rn = 50*d_np(:,5);
CN = 4*Rn./(50*abs(1+Gopt).^2);
%
% noise wave matrix CS
te_min = 10.^(0.1*Fmin)-1;
%
cs11 = 0.25*(te_min.*(abs(s11).^2-1)+CN.*abs(1-s11.*Gopt).^2);
%
cs12 = 0.25*(conj(s21).*(s11.*te_min-CN.*conj(Gopt).*(1-s11.*Gopt)));
%
cs22 = 0.25*(abs(s21).^2.*(te_min+CN.*abs(Gopt).^2));
%
end