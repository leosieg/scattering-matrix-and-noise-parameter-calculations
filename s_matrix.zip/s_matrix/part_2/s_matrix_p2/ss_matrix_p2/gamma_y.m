function [gsp,gcs] = gamma_y(y)
% 
% reflection coefficient and noise wave
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% g_y(y)
%
% y = normalized admittance
%
gsp = -(y-1)/(y+1);
%
% noise wave matrix (passive n-port)
gcs = (1-abs(gsp)^2)/4;	  	  
%
end