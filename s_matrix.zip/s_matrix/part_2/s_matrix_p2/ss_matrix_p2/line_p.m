function [sp,cs] = line_p(Zl,ll,freq,en)
% 
% S parameters, noise waves
% parallel line, open or short
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% [sp,cs] = line_p(Zl,ll,freq,en)
%
%      Zl = characteristic impedance/Ohm
%      ll = length/m
%      en = 'o' for open end, 's' for short end
%
c0 = 2.99792458e8;
%
if en = 'o'
y = 1i*50*tan(2*pi*freq*ll/c0)/Zl;
end
%
if en = 's'
y = 50/(1i*Zl*tan(2*pi*freq*ll/c0));
end
%
sp = [-y 2
       2 -y]/(y+2);
%
% noise wave matrix (passive n-port)
cs = (eye(2)-sp*sp')/4;	  	  
%
end