function [sp,cs] = p3sp
% 
% lossless parallel splitter
% S parameters and noise wave matrix
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
sp = [-1 2 2
      2 -1 2
	  2 2 -1]/3;
%
cs = 0*sp;	  	  
%
end