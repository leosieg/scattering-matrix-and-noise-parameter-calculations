function [sp,cs] = y_parallel(y)
% 
% S parameters, noise waves
% parallel normalized admittance
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% y_p(y)
%
% y = normalized admittance
%
sp = [-y 2
       2 -y]/(y+2);
%
% noise wave matrix (passive n-port)
cs = (eye(2)-sp*sp')/4;	  	  
%
end