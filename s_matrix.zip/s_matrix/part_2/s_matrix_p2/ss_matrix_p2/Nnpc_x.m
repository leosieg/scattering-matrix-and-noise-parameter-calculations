function [rs,rcs] = Nnpc_x(sx,csx,p_1x,p_2x,dsp)
%
% connection programm for two ports at n-port x
% S parameters and noise wave matrix
%
% Siegfried Martius
% Universitaet Erlangen-Nuernberg
% Lehrstuhl fuer Hochfrequenztechnik
% siegfried.martius@fau.de
% Version 2024/04
%
% [rs,rcs] = Nnpc_x(sx,csx,p_1x,p_2x,dsp)
%
%       sx = S-parameters
%      csx = noise wave parameters
%     p_1x = number port one for connection
%     p_2x = number port two for connection, important p_2x > p_1x !!!
%      dsp = display port information
%            dsp = 1, yes
%
% ==========================================
S_m = sx;
CS_m = csx;
% ==========================================
Px = p_1x;
Py = p_2x;
% ==========================================
%
% numbers of ports
Pm = length(S_m);
%
% matrix adjustments
%
% S_1 square matrix
S_1 = zeros(Pm-2,Pm-2);
CS_1 = zeros(Pm-2,Pm-2);
%
% S_2 two columns
S_2 = zeros(Pm-2,2);
CS_2 = zeros(Pm-2,2);
%
% S_3 two rows, transpose of S_2
S_3 = S_2'; 
%
% number ray 1...Pm
Nx = 1:Pm;
%
% read ports not connected
N_1 = Nx(1:Px-1);
N_2 = Nx(Px+1:Py-1);
N_3 = Nx(Py+1:Pm);
%
% number ray sorted
% ports not connected, ports connected
% important, take note of the order !!!
% 
Nuv = [N_1 N_2 N_3 Px Py];
%
if dsp == 1
% ---port number information------------
N_Tor = length(Nuv)-2;
N_Tor1 = [N_1 N_2 N_3];
N_Tor2 = linspace(1,N_Tor,N_Tor);
%
display('====================================')
display('==== connection x port x1 < x2 =====')
display(['port number x1: ' num2str(Px) '; port number x2: ' num2str(Py) ';'])
display(['port numbers old: ' num2str(N_Tor1)])
display(['port numbers new: ' num2str(N_Tor2)])
display('====================================')
% -------------------------------------
end
%
% insert of the dedicated S- and noise parameters
% in the right matrices
for m = 1:Pm-2
    for n = 1:Pm-2
        S_1(m,n) =  S_m(Nuv(m),Nuv(n));
       CS_1(m,n) = CS_m(Nuv(m),Nuv(n));
    end    
end
%
for m = 1:Pm-2
    S_2(m,1) =  S_m(Nuv(m),Px);
   CS_2(m,1) = CS_m(Nuv(m),Px);
    S_2(m,2) =  S_m(Nuv(m),Py);
   CS_2(m,2) = CS_m(Nuv(m),Py); 
end 
%
for m = 1:Pm-2
    S_3(1,m) = S_m(Px,Nuv(m));
    S_3(2,m) = S_m(Py,Nuv(m));
end
%
S_4 = [S_m(Px,Px) S_m(Px,Py)-1
       S_m(Py,Px)-1 S_m(Py,Py)];
%
M_r = -S_2*(S_4\eye(2));
%
CS_4 = [CS_m(Px,Px) CS_m(Px,Py)
        CS_m(Py,Px) CS_m(Py,Py)];
%
CS2Mr = CS_2*M_r';
%
% S-Matrix result
rs = S_1-S_2*(S_4\S_3);
%
% noise wave matrix result
rcs = CS_1+CS2Mr+CS2Mr'+M_r*CS_4*M_r';
%
end



