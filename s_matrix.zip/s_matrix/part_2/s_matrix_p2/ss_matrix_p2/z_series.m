function [sp,cs] = z_series(z)
% 
% S parameters, noise waves
% series normalized impedance
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% z_s(z)
%
% z = normalized impedance
%
sp = [z 2
      2 z]/(z+2);
%
% noise wave matrix (passive n-port)
cs = (eye(2)-sp*sp')/4;	  	  
%
end