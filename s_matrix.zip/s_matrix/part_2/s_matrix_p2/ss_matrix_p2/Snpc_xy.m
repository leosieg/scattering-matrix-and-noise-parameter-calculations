function rs = Snpc_xy(sx,sy,p_1x,p_2y,dsp)
%
% connection programm for one port of n-port x
% with one port of n-port y
% S parameters only !!!
%
% Siegfried Martius
% Universitaet Erlangen-Nuernberg
% Lehrstuhl fuer Hochfrequenztechnik
% siegfried.martius@fau.de
% Version 2024/04
%
%   rs = Snpc_xy(sx,sy,p_1x,p_2y,dsp)
%
%   sx = S-parameters n-port x
%   sy = S-parameters n-port y
% p_1x = number port one of n-port x for connection
% p_2y = number port two of n-port y for connection
%  dsp = display port information
%        dsp = 1, yes
% 
% ==========================================
S_x = sx;
S_y = sy;
% ========================================== 
P1x = p_1x;
P2y = p_2y;
% ==========================================
%
% numbers of x-ports
Px = length(S_x);
%
% numbers of y-ports
Py = length(S_y);
%
% matrix adjustments
%
% S_1 square matrix
S_1 = zeros(Px-1+Py-1,Px-1+Py-1);
%
% S_2 two columns
S_2 = zeros(Px-1+Py-1,2);
%
% S_3 two rows, transpose of S_2
S_3 = S_2';
%
% numbers ray 1...Px
Nx = 1:Px;
%
% read ports not connected n-port x
N_1x = Nx(1:P1x-1);
N_2x = Nx(P1x+1:Px);
%
% numbers ray 1...Py
Ny = 1:Py;
%
% read ports not connected n-port y
N_1y = Ny(1:P2y-1);
N_2y = Ny(P2y+1:Py);
%
% numbers ray sorted
% ports not connected, ports connected
% important, take note of the order !!!
Nuv = [N_1x N_2x N_1y N_2y P1x P2y];
%
if dsp == 1
% ---port number information-----------
N_Tor = length(Nuv)-2;
N_Tor1 = [N_1x N_2x N_1y N_2y];
N_Tor2 = linspace(1,N_Tor,N_Tor);
%
display('====================================')
display('== connection x-port <--> y-port ===')
display(['port number x: ' num2str(P1x) '; port number y: ' num2str(P2y) ';'])
display(['port numbers old: ' num2str(N_Tor1)])
display(['port numbers new: ' num2str(N_Tor2)])
display('====================================')
% -------------------------------------
end
%
% insert of the dedicated S parameters
% in the right matrices
for m = 1:Px-1
    %
    for n = 1:Px-1
        %
        S_1(m,n) =  S_x(Nuv(m),Nuv(n));
        %
    end
    %
end
%
for m = Px:Px+Py-2
    %
    for n = Px:Px-1+Py-1
        %
        S_1(m,n) = S_y(Nuv(m),Nuv(n));
        %
    end
    %
end
%
for m = 1:Px-1
    %
    S_2(m,1) = S_x(Nuv(m),P1x);
    %
end
%
for m = 1:Py-1
    %
    S_2(Px-1+m,2) = S_y(Nuv(Px-1+m),P2y);
    %
end
%
for m = 1:Px-1
    %
    S_3(1,m) = S_x(P1x,Nuv(m));
    %
end
%
for m = 1:Py-1
    %
    S_3(2,Px-1+m) = S_y(P2y,Nuv(Px-1+m));
    %
end
%
S_4 = [S_x(P1x,P1x) -1
                 -1 S_y(P2y,P2y)];
%
% S-matrix result
rs = S_1-S_2*(S_4\S_3);
%
end


