% amplifier frequency analysis
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% clear workspace, adjustments
clear all
close all
set(0,'DefaultLineLineWidth',4);
set(0,'DefaultAxesFontSize',14);
set(0,'DefaultTextFontSize',14);
set(0,'DefaultAxesClipping','on');
%
% adjustments
scsz = get(0,'ScreenSize');
pos1 = [0.75*scsz(3),0.64*scsz(4),0.25*scsz(3),0.3*scsz(4)];
dfig = -30;
%
% single frequency analysis for generate connections
% dsp = 1
%freq = 1e9;
%dsp = 1;
%
% bandpass analysis
% dsp ne 1
% bandpass analysis
freq = [0:2/500:2]*1e9;
dsp = 0;
%
tic
% ========================================================
%
[s11,s12,s13,s22,s23,s33] = wilkinson_circuit(freq,1e9);
%
% ========================================================
toc
%
% find index for freq ca. 1 GHz
[mi,fi] = min(abs(freq-1e9));
%
display (' ')
display(['values for frequency f = ' num2str(freq(fi)/1e9) ' GHz'])
sp = [s11(fi) s12(fi) s13(fi)
      s12(fi) s22(fi) s23(fi)
      s13(fi) s23(fi) s33(fi)]
%
if dsp == 1
   return
end
% ========================================================
% --------------------------------------------------------
nfig = 1;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s11)))
axis([min(freq)/1e9 max(freq)/1e9 -50 0])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{11}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 2;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s12)))
axis([min(freq)/1e9 max(freq)/1e9 -5 0])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{12}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 3;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s13)))
axis([min(freq)/1e9 max(freq)/1e9 -5 0])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{13}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 4;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s22)))
axis([min(freq)/1e9 max(freq)/1e9 -50 0])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{22}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 5;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s23)))
axis([min(freq)/1e9 max(freq)/1e9 -50 0])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{23}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 6;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s33)))
axis([min(freq)/1e9 max(freq)/1e9 -50 0])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{33}|^2/dB \rightarrow')
% --------------------------------------------------------


