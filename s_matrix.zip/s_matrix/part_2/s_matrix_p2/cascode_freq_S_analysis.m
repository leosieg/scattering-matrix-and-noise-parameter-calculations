% cascode frequency S analysis
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% clear workspace, adjustments
clear all
close all
set(0,'DefaultLineLineWidth',4);
set(0,'DefaultAxesFontSize',14);
set(0,'DefaultTextFontSize',14);
set(0,'DefaultAxesClipping','on');
%
% adjustments
scsz = get(0,'ScreenSize');
pos1 = [0.75*scsz(3),0.64*scsz(4),0.25*scsz(3),0.3*scsz(4)];
dfig = -30;
%
% single frequency analysis for generate connections
% dsp = 1
freq = 1e9;
dsp = 1;
%
% bandpass analysis
% dsp ne 1
%freq = [0.9:0.001:1.1]*1e9;
%dsp = 0;
%
% broadband analysis, overall stability
% dsp ne 1
%freq = logspace(2,10,100);
% dsp = 0;
%
tic
% ========================================================
%
[s11,s12,s21,s22] = cascode_S_circuit(freq,dsp);
%
% ========================================================
toc
%
ds = s11.*s22-s12.*s21;
%
% factors stability
muL = (1-abs(s11).^2)./(abs(s22-conj(s11).*ds)+abs(s12.*s21));
muS = (1-abs(s22).^2)./(abs(s11-conj(s22).*ds)+abs(s12.*s21));
%
% find index for freq ca. 1 GHz
[mi,fi] = min(abs(freq-1e9));
%
display (' ')
display(['values for frequency f = ' num2str(freq(fi)/1e9) ' GHz'])
sp = [s11(fi) s12(fi)
      s21(fi) s22(fi)]
%
if dsp == 1
   return
end
% ========================================================
% --------------------------------------------------------
nfig = 1;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s21)))
axis([min(freq)/1e9 max(freq)/1e9 20 25])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{21}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 2;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s11)))
axis([min(freq)/1e9 max(freq)/1e9 -2 0])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{11}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 3;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s22)))
axis([min(freq)/1e9 max(freq)/1e9 0 0.2])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{22}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 4;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,muS,'-r',freq/1e9,muL,'-b')
axis([min(freq)/1e9 max(freq)/1e9 -1.5 1])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('\mu_S,\mu_L \rightarrow')
%
legend('\mu_S','\mu_L','Location','SouthEast')
legend('boxoff')
% --------------------------------------------------------
nfig = 5;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
ssks(sp,'z')
% --------------------------------------------------------
nfig = 6;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
sskl(sp,'y')
% --------------------------------------------------------
%



