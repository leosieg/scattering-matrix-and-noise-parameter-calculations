function [rsp11,rsp12,rsp13,rsp22,rsp23,rsp33] = wilkinson_circuit(freq,freq_0)
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% filter_cicuit(freq,dsp)
%
% freq = current frequency/Hz
%  dsp = display parameter
%
freq_N = length(freq);
%
% matrix adjustmens
rsp11 = zeros(1,freq_N);
rsp12 = zeros(1,freq_N);
rsp13 = zeros(1,freq_N);
rsp22 = zeros(1,freq_N);
rsp23 = zeros(1,freq_N);
rsp33 = zeros(1,freq_N);
%
c0 = 2.99792458e8;
% lambda/4 for freq_0
l4_0 = c0/(4*freq_0);
%
q = 1;
%
while q <= freq_N
%
[rsp,rcs] = wilkinson_s(l4_0,freq(q));
%
% S parameters
rsp11(q) = rsp(1,1);
rsp12(q) = rsp(1,2);
rsp13(q) = rsp(1,3);
rsp22(q) = rsp(2,2);
rsp23(q) = rsp(2,3);
rsp33(q) = rsp(3,3);
%
q = q+1;
%
end
end
