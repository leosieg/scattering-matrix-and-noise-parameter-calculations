function [rsp11,rsp12,rsp21,rsp22,rcs11,rcs12,rcs22] = amp_N02_circuit(freq,dsp)
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% amp_circuit(freq,dsp)
%
% freq = current frequency/Hz
%  dsp = display parameter
%        dsp == 1 display 
%
freq_N = length(freq);
%
% matrix adjustmens
rsp11 = zeros(1,freq_N);
rsp12 = zeros(1,freq_N);
rsp21 = zeros(1,freq_N);
rsp22 = zeros(1,freq_N);
%
rcs11 = zeros(1,freq_N);
rcs12 = zeros(1,freq_N);
rcs22 = zeros(1,freq_N);
%
c0 = 2.99792458e8;
% lambda/4 for freq = 5e9
l4_0 = c0/(4*5e9);
%
[s11,s12,s21,s22,cs11,cs12,cs22] = s2spl_N('fhc40lg_S.txt','fhc40lg_N.txt',freq);
%
q = 1;
%
while q <= freq_N
%
fq = freq(q);
%
% Wilkinson splitter 5 GHz
% -> lambda/4 = 14/m
%
[wsp,wcs] = wilkinson_s(l4_0,fq);
%
% transistor
tsp = [s11(q) s12(q)
       s21(q) s22(q)];
%
tcs =    [cs11(q) cs12(q)
    conj(cs12(q)) cs22(q)];
%
% lambda/4-line 50 Ohm
[lsp,lcs] = line_s(50,l4_0,fq);
%
% lambda/4-line 50 Ohm-transistor
[ltsp,ltcs] = Nnpc_xy(lsp,lcs,tsp,tcs,2,1,dsp);
%
% transistor-lambda/4-line 50 Ohm
[tlsp,tlcs] = Nnpc_xy(tsp,tcs,lsp,lcs,2,1,dsp);
% 
% Wilkinson-Wilkinson
[rsp,rcs] = Nnpc_xy(wsp,wcs,wsp,wcs,2,1,dsp);
%
% 2-Wilkinson-line
[rsp,rcs] = Nnpc_xy(rsp,rcs,lsp,lcs,2,1,dsp);
%
% 2-Wilkinson-line-Wilkinson
[rsp,rcs] = Nnpc_xy(rsp,rcs,wsp,wcs,4,1,dsp);
%
% save input circuit
wlsp = rsp;
wlcs = rcs;
%
% main cicuit
[rsp,rcs] = Nnpc_xy(rsp,rcs,tlsp,tlcs,2,1,dsp);
%
[rsp,rcs] = Nnpc_xy(rsp,rcs,ltsp,ltcs,2,1,dsp);
%
[rsp,rcs] = Nnpc_xy(rsp,rcs,tlsp,tlcs,2,1,dsp);
%
[rsp,rcs] = Nnpc_xy(rsp,rcs,ltsp,ltcs,2,1,dsp);
%
% output circuit with saved input circuit
[rsp,rcs] = Nnpc_xy(rsp,rcs,wlsp,wlcs,2,5,dsp);
%
[rsp,rcs] = Nnpc_x(rsp,rcs,2,8,dsp);
%
[rsp,rcs] = Nnpc_x(rsp,rcs,2,6,dsp);
%
[rsp,rcs] = Nnpc_x(rsp,rcs,2,4,dsp);
%
% S parameters
rsp11(q) = rsp(1,1);
rsp12(q) = rsp(1,2);
rsp21(q) = rsp(2,1);
rsp22(q) = rsp(2,2);
%
% noise wave matrix
rcs11(q) = rcs(1,1);
rcs12(q) = rcs(1,2);
rcs22(q) = rcs(2,2);
%
q = q+1;
%
end
end
