function [rsp11,rsp12,rsp21,rsp22] = amp_S_circuit(freq,dsp)
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% amp_circuit(freq,dsp)
%
% freq = current frequency/Hz
%  dsp = display parameter
%        dsp == 1 display 
%
freq_N = length(freq);
%
% matrix adjustmens
rsp11 = zeros(1,freq_N);
rsp12 = zeros(1,freq_N);
rsp21 = zeros(1,freq_N);
rsp22 = zeros(1,freq_N);
%
c0 = 2.99792458e8;
% lambda/4 for freq = 5e9
l4_0 = c0/(4*5e9);
%
[s11,s12,s21,s22] = s2spl_S('fhc40lg_S.txt',freq);
%
q = 1;
%
while q <= freq_N
%
fq = freq(q);
%
% Wilkinson splitter 5 GHz
% -> lambda/4 = l4/m
[wsp,wcs] = wilkinson_s(l4_0,fq);
%
% transistor
tsp = [s11(q) s12(q)
       s21(q) s22(q)];
%
% lambda/4-line 50 Ohm
[lsp,lcs] = line_s(50,l4_0,fq);
%
% amplifier circuit
%
% input Wilkinson-transistor
rsp = Snpc_xy(wsp,tsp,2,1,dsp);
%
% Wilkinson-transistor-line
rsp = Snpc_xy(rsp,lsp,3,1,dsp);
%
% Wilkinson-line-other-output
rsp = Snpc_xy(rsp,lsp,2,1,dsp);
%
% Wilkinson-line-other-output-line
rsp = Snpc_xy(rsp,tsp,3,1,dsp);
%
% whole circuit-output Wilkinson
rsp = Snpc_xy(rsp,wsp,2,2,dsp);
%
% connect inner open ends
rsp = Snpc_x(rsp,2,4,dsp);
%
% S parameters
rsp11(q) = rsp(1,1);
rsp12(q) = rsp(1,2);
rsp21(q) = rsp(2,1);
rsp22(q) = rsp(2,2);
%
q = q+1;
%
end
end
