% test program 
% inductor at emitter
% three port computation
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
clear all
close all
%
% frequency
freq = 1e9;
%
% spline with data for transistor common emitter
[s11,s12,s21,s22,cs11,cs12,cs22] = s2spl_N('BFP640F_S.txt','BFP640F_N.txt',freq);
%
% 2 port transistor matrices common emitter
t2sp = [s11 s12
        s21 s22];
t2cs = [cs11 cs12
  conj(cs12) cs22];
%
% 3 port transistor matrix
[t3sp,t3cs] = t2tot3ce_N(t2sp,t2cs);
%
% normalized reactance/suszeptance
[jwl,jwc] = jomegalc(freq);
%
% reflection coefficient and noise from emitter inductor
[gsp,gcs] = gamma_z(jwl*0.5e-9);
%
display(' ')
display('===== inductor at emitter =====')
display(' ')
% transistor with emitter inductor
[rsp,rcs] = Nnpc_xy(t3sp,t3cs,gsp,gcs,3,1,1)
%
%
s11 = rsp(1,1);
s21 = rsp(2,1);
%
cs11 = rcs(1,1);
cs12 = rcs(1,2);
cs22 = rcs(2,2);
%
% noise parameters
% by means of
% noise wave matrix CS
p = 2*cs11+2*(cs22*(1+abs(s11)^2)-...
      2*real(cs12*conj(s11)*s21))/abs(s21)^2;
%
q = 4*abs(cs22*s11-cs12*s21)/abs(s21)^2;
%
CN = real(p+sqrt(p^2-q^2))
%
Gopt = 4*conj((cs22*s11-cs12*s21))/(CN*abs(s21)^2)
%
Rn = 50*CN*abs(1+Gopt)^2/4
%
te_min = 4*real(cs22)/abs(s21)^2-CN*abs(Gopt)^2;
%
Fmin = 10*log10(1+te_min)