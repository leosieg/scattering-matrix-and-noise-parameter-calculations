function [rsp11,rsp12,rsp21,rsp22] = amp_S02_circuit(freq,dsp)
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% amp_circuit(freq,dsp)
%
% freq = current frequency/Hz
%  dsp = display parameter
%        dsp == 1 display 
%
freq_N = length(freq);
%
% matrix adjustmens
rsp11 = zeros(1,freq_N);
rsp12 = zeros(1,freq_N);
rsp21 = zeros(1,freq_N);
rsp22 = zeros(1,freq_N);
%
c0 = 2.99792458e8;
% lambda/4 for freq = 5e9
l4_0 = c0/(4*5e9);
%
[s11,s12,s21,s22] = s2spl_S('fhc40lg_S.txt',freq);
%
q = 1;
%
while q <= freq_N
%
fq = freq(q);
%
% Wilkinson splitter 5 GHz
% -> lambda/4 = 14/m
%
[wsp,wcs] = wilkinson_s(l4_0,fq);
%
% transistor
tsp = [s11(q) s12(q)
       s21(q) s22(q)];
%
% lambda/4-line 50 Ohm
lsp = line_s(50,l4_0,fq);
%
% lambda/4-line 50 Ohm-transistor
ltsp = Snpc_xy(lsp,tsp,2,1,dsp);
%
% transistor-lambda/4-line 50 Ohm
tlsp = Snpc_xy(tsp,lsp,2,1,dsp);
%
% input circuit 
% Wilkinson-Wilkinson
rsp = Snpc_xy(wsp,wsp,2,1,dsp);
%
% 2-Wilkinson-line
rsp = Snpc_xy(rsp,lsp,2,1,dsp);
%
% 2-Wilkinson-line-Wilkinson
rsp = Snpc_xy(rsp,wsp,4,1,dsp);
%
% save input circuit
wlsp = rsp;
%
% main cicuit
rsp = Snpc_xy(rsp,tlsp,2,1,dsp);
%
rsp = Snpc_xy(rsp,ltsp,2,1,dsp);
%
rsp = Snpc_xy(rsp,tlsp,2,1,dsp);
%
rsp = Snpc_xy(rsp,ltsp,2,1,dsp);
%
% output circuit with saved input circuit
rsp = Snpc_xy(rsp,wlsp,2,5,dsp);
%
rsp = Snpc_x(rsp,2,8,dsp);
%
rsp = Snpc_x(rsp,2,6,dsp);
%
rsp = Snpc_x(rsp,2,4,dsp);
%
% S parameters
rsp11(q) = rsp(1,1);
rsp12(q) = rsp(1,2);
rsp21(q) = rsp(2,1);
rsp22(q) = rsp(2,2);
%
q = q+1;
%
end
end
