% MATLAB-Startfile
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
set(0,'DefaultFigurePaperType','a4')
%set(0,'DefaultFigurePaperType','usletter') 
%
p1=pwd;
path([p1 '\ss_matrix_p2'],path);
path(p1,path);

