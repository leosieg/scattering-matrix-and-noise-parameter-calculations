function [rsp11,rsp12,rsp21,rsp22] = filter_circuit(freq,dsp)
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% filter_cicuit(freq,dsp)
%
% freq = current frequency/Hz
%  dsp = display parameter
%        dsp == 1 display 
%
freq_N = length(freq);
%
% matrix adjustmens
rsp11 = zeros(1,freq_N);
rsp12 = zeros(1,freq_N);
rsp21 = zeros(1,freq_N);
rsp22 = zeros(1,freq_N);
%
q = 1;
%
while q <= freq_N
%
fq = freq(q);
%
% nomalized inductance, capacitance
[jwl,jwc] = jomegalc(fq);
%
[sp1,cs1] = y_parallel(jwc*10.659e-12+1/(jwl*2.4755e-9));
%
[sp2,cs2] = z_series(jwl*26.5991e-9+1/(jwc*991.9785e-15));
%
[sp3,cs3] = y_parallel(jwc*17.2369e-12+1/(jwl*1.5308e-9));
%
[sp4,cs4] = z_series(jwl*26.5991e-9+1/(jwc*991.9785e-15));
%
[sp5,cs5] = y_parallel(jwc*10.659e-12+1/(jwl*2.4755e-9));
%
% filter circuit
%
rsp = Snpc_xy(sp1,sp2,2,1,dsp);
%
rsp = Snpc_xy(rsp,sp3,2,1,dsp);
%
rsp = Snpc_xy(rsp,sp4,2,1,dsp);
%
rsp = Snpc_xy(rsp,sp5,2,1,dsp);
%
% S parameters
rsp11(q) = rsp(1,1);
rsp12(q) = rsp(1,2);
rsp21(q) = rsp(2,1);
rsp22(q) = rsp(2,2);
%
q = q+1;
%
end
end
