% lna frequency N analysis
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% clear workspace, adjustments
clear all
close all
set(0,'DefaultLineLineWidth',4);
set(0,'DefaultAxesFontSize',14);
set(0,'DefaultTextFontSize',14);
set(0,'DefaultAxesClipping','on');
%
% adjustments
scsz = get(0,'ScreenSize');
pos1 = [0.75*scsz(3),0.64*scsz(4),0.25*scsz(3),0.3*scsz(4)];
dfig = -30;
%
% single frequency analysis for generate connections
% dsp = 1
%freq = 1e9;
%dsp = 1;
%
% bandpass analysis
% dsp ne 1
freq = [0.9:0.001:1.1]*1e9;
dsp = 0;
%
% broadband analysis, overall stability
% dsp ne 1
%freq = logspace(0.1,10,100);
% dsp = 0;
%
tic
% ========================================================
%
[s11,s12,s21,s22,cs11,cs12,cs22] = lna_N_circuit(freq,dsp);
%
% ========================================================
toc
%
ds = s11.*s22-s12.*s21;
%
% factors stability
muL = (1-abs(s11).^2)./(abs(s22-conj(s11).*ds)+abs(s12.*s21));
muS = (1-abs(s22).^2)./(abs(s11-conj(s22).*ds)+abs(s12.*s21));
%
% noise parameters
% by means of
% noise wave matrix CS
p = 2*cs11+2*(cs22.*(1+abs(s11).^2)-...
      2*real(cs12.*conj(s11).*s21))./abs(s21).^2;
%
q = 4.*abs(cs22.*s11-cs12.*s21)./abs(s21).^2;
%
CN = real(p+sqrt(p.^2-q.^2));
%
Gopt = 4*conj((cs22.*s11-cs12.*s21))./(CN.*abs(s21).^2);
%
Rn = 50*CN.*abs(1+Gopt).^2/4;
%
te_min = 4*real(cs22)./abs(s21).^2-CN.*abs(Gopt).^2;
%
Fmin = 10*log10(1+te_min);
%
% noise figure 50 Ohm
F50 = 10*log10(10.^(Fmin/10)+CN.*abs(Gopt).^2);
%
% find index for freq ca. 1 GHz
[mi,fi] = min(abs(freq-1e9));
%
display (' ')
display(['values for frequency f = ' num2str(freq(fi)/1e9) ' GHz'])
sp = [s11(fi) s12(fi)
      s21(fi) s22(fi)]
%
np = [Fmin(fi)
       Rn(fi)
       CN(fi)
       Gopt(fi)]
%
CS  =  [cs11(fi) cs12(fi)
  conj(cs12(fi)) cs22(fi)]
%
% by means of
% noise wave matrix CT
% for this
% CS -> CT
p = 1;
freq_p = length(freq);
%
while p <= freq_p
%
    cstoct = [1 -s11(p)
              0 -s21(p)]\eye(2);
%
        cs = [cs11(p) cs12(p)
        conj(cs12(p)) cs22(p)];
%
        ct = cstoct*cs*cstoct';
%
   ct11(p) = ct(1,1);
   ct12(p) = ct(1,2);
   ct22(p) = ct(2,2);
%
p = p+1;
end
%
m = (ct11+ct22)./ct12;
%
Gopt_t = m.*(1-sqrt(1-4./abs(m).^2))/2;
%
CN_t = real(4*ct12./conj(Gopt));
%
Rn_t = 50*CN.*abs(1+Gopt).^2/4;
%
te_min = CN-4*real(ct11);
%
Fmin_t = 10*log10(1+te_min);
%
np_t = [Fmin_t(fi)
       Rn_t(fi)
       CN_t(fi)
       Gopt_t(fi)]
%
CT  =  [ct11(fi) ct12(fi)
  conj(ct12(fi)) ct22(fi)]
%
if dsp == 1
   return
end
% ========================================================
% --------------------------------------------------------
nfig = 1;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s21)))
axis([min(freq)/1e9 max(freq)/1e9 10 20])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{21}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 2;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s11)))
axis([min(freq)/1e9 max(freq)/1e9 -50 0])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{11}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 3;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s22)))
axis([min(freq)/1e9 max(freq)/1e9 -50 0])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{22}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 4;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,muS,'-r',freq/1e9,muL,'-b')
axis([min(freq)/1e9 max(freq)/1e9 0 4])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('\mu_S,\mu_L \rightarrow')
%
legend('\mu_S','\mu_L','Location','SouthEast')
legend('boxoff')
% --------------------------------------------------------
nfig = 5;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
ssks(sp,'z')
% --------------------------------------------------------
nfig = 6;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
sskl(sp,'y')
% --------------------------------------------------------
nfig = 7;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,Fmin,'-r',freq/1e9,F50,'-b')
axis([min(freq)/1e9 max(freq)/1e9 0.5 0.7])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('F/dB \rightarrow')
%
legend('F_{min}','F_{\Gamma=0}','Location','SouthEast')
legend('boxoff')
% --------------------------------------------------------
nfig = 8;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
valnc = [0:0.5:3];
ncir(np,'z',valnc)
% --------------------------------------------------------
nfig = 9;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
valnc = [0:0.1:3];
ncirp(np,'y',valnc,1)
%



