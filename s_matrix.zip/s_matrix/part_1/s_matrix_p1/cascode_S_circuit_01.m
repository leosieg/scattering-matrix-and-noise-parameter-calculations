function [rs11,rs12,rs21,rs22] = cascode_S_circuit_01(freq)
%
% cascode circuit analysis signal only
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% freq/Hz
%
% emitter/source data
[s11,s12,s21,s22] = sspl_S('BFP640F_S.txt',freq);
%
%	   
freq_q = length(freq);
%
rs11 = zeros(1,freq_q);
rs12 = zeros(1,freq_q);
rs21 = zeros(1,freq_q);
rs22 = zeros(1,freq_q);
%
q = 1;
%
while q <= freq_q
%
% date emitter/source -> data base/gate, collector/drain
[spe,spb,spc,tpe,tpb,tpc] = stnc_S(s11(q),s12(q),s21(q),s22(q));
%
% ===== topology cascode =====
%
% cascade circuit emitter - base
rsp = sscs(spe,spb);
%
% =============================
%
rs11(q) = rsp(1,1);
rs12(q) = rsp(1,2);
rs21(q) = rsp(2,1);
rs22(q) = rsp(2,2);
%
q = q+1;
%	  
end
end