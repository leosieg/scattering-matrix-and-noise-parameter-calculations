function [rs11,rs12,rs21,rs22] = amp_S_circuit_01(freq)
%
% amplifier circuit analysis signal only
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% freq/Hz
%
[s11,s12,s21,s22] = sspl_S('BFP640F_S.txt',freq);
%	   
freq_q = length(freq);
%
rs11 = zeros(1,freq_q);
rs12 = zeros(1,freq_q);
rs21 = zeros(1,freq_q);
rs22 = zeros(1,freq_q);
%
q = 1;
%
while q <= freq_q
%
fq = freq(q);
[jwl,jwc] = jomegalc(fq);
%
sp = [s11(q) s12(q)
      s21(q) s22(q)];
%
% ===== topology amplifier =====
%
% transistor
rsp = sssz(sp,jwl*0.14e-9);
%
rsp = sspy(rsp,1/(445/50+jwl*1.9e-9));
%
% output
rsp = ssoy(rsp,1/(777/50+jwl*1.65e-9));
%
rsp = sscs(rsp,llsl(46,3.8e-3,fq));
%
rsp = sscs(rsp,llsl(54,91.6e-3,fq));
%
rsp = sscs(rsp,stra(1));
%
% input
rsp = ssiy(rsp,llps(100,74.9e-3,fq));
%
rsp = sscs(llsl(50,299.8e-3,fq),rsp);
%
% =============================
%
rs11(q) = rsp(1,1);
rs12(q) = rsp(1,2);
rs21(q) = rsp(2,1);
rs22(q) = rsp(2,2);
%
q = q+1;
%	  
end
end