function [rs11,rs12,rs21,rs22] = tran4p_S_circuit_01(freq)
%
% four transistors parallel circuit analysis signal only
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% freq/Hz
%
[s11,s12,s21,s22] = sspl_S('BFP640F_S.txt',freq);
%	   
freq_q = length(freq);
%
rs11 = zeros(1,freq_q);
rs12 = zeros(1,freq_q);
rs21 = zeros(1,freq_q);
rs22 = zeros(1,freq_q);
%
q = 1;
%
while q <= freq_q
%
sp = [s11(q) s12(q)
      s21(q) s22(q)];
%
% ===== topology transistor parallel =====
%
% two transistors parallel
rsp = sspp(sp,sp);
%
% three transistors parallel
rsp = sspp(rsp,sp);
%
% four transistors parallel
rsp = sspp(rsp,sp);
%
% =============================
%
rs11(q) = rsp(1,1);
rs12(q) = rsp(1,2);
rs21(q) = rsp(2,1);
rs22(q) = rsp(2,2);
%
q = q+1;
%	  
end
end