function [rs11,rs12,rs21,rs22,rFmin,rRn,rCN,rGopt] = amp_circuit_01(freq)
%
% amplifier circuit analysis with noise
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% freq/Hz
%
% noise wave matrix for lossless two port
cto = [0 0
       0 0];
%	   
freq_q = length(freq);
%
rs11 = zeros(1,freq_q);
rs12 = zeros(1,freq_q);
rs21 = zeros(1,freq_q);
rs22 = zeros(1,freq_q);
%
rFmin = zeros(1,freq_q);
rRn = zeros(1,freq_q);
rCN = zeros(1,freq_q);
rGopt = zeros(1,freq_q);
%
[s11,s12,s21,s22,Fmin,Rn,CN,Gopt] = sspl_N('BFP640F_S.txt','BFP640F_N.txt',freq);
%
q = 1;
%
while q <= freq_q
%
fq = freq(q);
[jwl,jwc] = jomegalc(fq);
%
sp = [s11(q) s12(q)
      s21(q) s22(q)];
%
np = [Fmin(q)
      Rn(q)
      CN(q)
      Gopt(q)];
%
ct = nnct(np);
%
% ===== topology amplifier =====
%
% transistor
[rsp,rct] = nssz(sp,ct,jwl*0.14e-9);
%
[rsp,rct] = nspy(rsp,rct,1/(445/50+jwl*1.9e-9));
%
% output
[rsp,rct] = nsoy(rsp,rct,1/(777/50+jwl*1.65e-9));
%
[rsp,rct] = nscs(rsp,rct,llsl(46,3.8e-3,fq),cto);
%
[rsp,rct] = nscs(rsp,rct,llsl(54,91.6e-3,fq),cto);
%
[rsp,rct] = nscs(rsp,rct,stra(1),cto);
%
% input
[rsp,rct] = nsiy(rsp,rct,llps(100,74.9e-3,fq));
%
[rsp,rct] = nscs(llsl(50,299.8e-3,fq),cto,rsp,rct);
%
% =============================
%
rs11(q) = rsp(1,1);
rs12(q) = rsp(1,2);
rs21(q) = rsp(2,1);
rs22(q) = rsp(2,2);
%
np = ncnp(rct);
%
rFmin(q) = real(np(1,1));
rRn(q) = real(np(2,1));
rCN(q) = real(np(3,1));
rGopt(q) = np(4,1);
%
q = q+1;
%	  
end
end