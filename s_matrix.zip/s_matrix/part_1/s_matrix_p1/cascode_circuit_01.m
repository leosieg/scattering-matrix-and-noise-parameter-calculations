function [rs11,rs12,rs21,rs22,rFmin,rRn,rCN,rGopt] = cascode_circuit_01(freq)
%
% cascode circuit analysis with noise
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% freq/Hz
%
% emitter/source data
[s11,s12,s21,s22,Fmin,Rn,CN,Gopt] = sspl_N('BFP640F_S.txt','BFP640F_N.txt',freq);
%
%
cto = [0 0
       0 0];
%	   
freq_q = length(freq);
%
rs11 = zeros(1,freq_q);
rs12 = zeros(1,freq_q);
rs21 = zeros(1,freq_q);
rs22 = zeros(1,freq_q);
%
rFmin = zeros(1,freq_q);
rRn = zeros(1,freq_q);
rCN = zeros(1,freq_q);
rGopt = zeros(1,freq_q);
%
q = 1;
%
while q <= freq_q
%
% date emitter/source -> data base/gate, collector/drain
[spe,spb,spc,tpe,tpb,tpc,npe,npb,npc,cte,ctb,ctc,spo,cto] = ...
    stnc_N(s11(q),s12(q),s21(q),s22(q),Fmin(q),Rn(q),CN(q),Gopt(q));
%
% ===== topology cascode =====
%
% cascade circuit emitter - base -> cascode
[rsp,rct] = nscs(spe,cte,spb,ctb);
%
% =============================
%
rs11(q) = rsp(1,1);
rs12(q) = rsp(1,2);
rs21(q) = rsp(2,1);
rs22(q) = rsp(2,2);
%
np = ncnp(rct);
%
rFmin(q) = real(np(1,1));
rRn(q) = real(np(2,1));
rCN(q) = real(np(3,1));
rGopt(q) = np(4,1);
%
q = q+1;
%	  
end
end