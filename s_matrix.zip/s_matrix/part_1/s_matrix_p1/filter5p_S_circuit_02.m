function [rs11,rs12,rs21,rs22] = filter5p_S_circuit_02(freq)
%
% filter circuit analysis
% structure with output connection
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% freq/Hz
%
% S - matrix through
spo = [0 1
       1 0];
%
freq_q = length(freq);
%
rs11 = zeros(1,freq_q);
rs12 = zeros(1,freq_q);
rs21 = zeros(1,freq_q);
rs22 = zeros(1,freq_q);
%
q = 1;
%
while q <= freq_q
%
fq = freq(q);
[jwl,jwc] = jomegalc(fq);
%
% ===== topology filter =====
%
rsp = ssoy(spo,jwc*10.659e-12+1/(jwl*2.4755e-9));
%
rsp = ssoz(rsp,jwl*26.5991e-9+1/(jwc*991.9786e-15));
%
rsp = ssoy(rsp,jwc*17.2369e-12+1/(jwl*1.5308e-9));
%
rsp = ssoz(rsp,jwl*26.5991e-9+1/(jwc*991.9786e-15));
%
rsp = ssoy(rsp,jwc*10.659e-12+1/(jwl*2.4755e-9));
%
% =============================
%
rs11(q) = rsp(1,1);
rs12(q) = rsp(1,2);
rs21(q) = rsp(2,1);
rs22(q) = rsp(2,2);
%
q = q+1;
%	  
end
end