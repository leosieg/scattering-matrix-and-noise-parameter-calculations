function [scs,ctcs] = nscs(sx,ctx,sy,cty)
%
% sx-sy cascade connection with noise 
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
% 
% [scs,ctcs] = nscs(sx,ctx,sy,cty)
%
%         sx = S-parameters 1. two port
%        ctx = noise wave matrix 1. two port
%         sy = S-parameters 2. two port
%        cty = noise wave matrix 2. two port
%
% S-matrix cascade
s1 = [sx(1,1) 0
            0 sy(2,2)];
s2 = [sx(1,2) 0
            0 sy(2,1)];
s3 = [sy(1,1) 1 
            1 sx(2,2)];
s4 = [sx(2,1) 0 
            0 sy(1,2)];
%
scs = s1+s2*s3*s4/(1-sx(2,2)*sy(1,1));
%
% T-matrix cascade
tx = stot(sx);
%
% cascade formula for noise correlation matrix ctcs
ctcs = ctx+tx*cty*tx';
%
end
