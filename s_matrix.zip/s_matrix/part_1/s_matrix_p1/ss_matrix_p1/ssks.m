 function ssks(s,dsp)
%
% stability circle source plane
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% ssks(s,diag)
%
%   s = S-parameters two port
% dsp = display paramter
%      'z' -> Smith chart z version
%	   'y' -> Smith chart y version 
%
s11 = s(1,1);
s12 = s(1,2);
s21 = s(2,1);
s22 = s(2,2);
%
ds = s11*s22-s12*s21;
c1 = s11-conj(s22)*ds;
c2 = s22-conj(s11)*ds;
%
% stability factors
mu1 = (1-abs(s11)^2)/(abs(c2)+abs(s12*s21));
mu2 = (1-abs(s22)^2)/(abs(c1)+abs(s12*s21));
%
mu = [mu1,mu2];
%
% stability circle
cs = conj(c1)/(abs(s11)^2-abs(ds)^2);
%
rs = abs(s12*s21/(abs(s11)^2-abs(ds)^2));
%
% point density
pk = 200/(2*pi);
phi = linspace(0,2*pi,pk*2*pi);
%
z = cs + rs*exp(j*phi);
%
valsmith = [0 0.2 0.5 1 2 5];
%
% Smith chart
if dsp == 'z'
   smith_z(valsmith);
else
   smith_y(valsmith);
end 
%
axis equal
axis off
hold on
%
plot(real(z),imag(z),'-k','LineWidth',2)
%
% s11
xcs = real(s11);
ycs = imag(s11);
%
plot(xcs,ycs,'ok','LineWidth',5)
%
h = text(xcs,ycs,'s_{11}','FontSize',14,'color','k','FontWeight','bold');
set(h,'VerticalAlignment', 'bottom');
%
text(-1,1.1,'stability circle, source plane','FontSize',14,'color','k','FontWeight','bold')
xlim([-2.1 2.1]);
ylim([-1.05 1.05]);
%
disp(['stability factors mu = ' num2str(mu,4)])
%
end