function np = ncnp(ct)
%
% noise matrix ct -> noise parameters np
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
% 
%      np = ncnp(ct)
%
%      ct = noise wave matrix
% np(1,1) = Fmin/dB
% np(2,1) = Rn/Ohm
% np(3,1) = CN
% np(4,1) = Gopt
%
c11 = real(ct(1,1));
c12 = ct(1,2);
c22 = real(ct(2,2));
%
m = (c11+c22)/c12;
%
Gopt = m*(1-sqrt(1-4/abs(m)^2))/2;
CN = real(4*c12/conj(Gopt));
Rn = CN*50*abs(1+Gopt)^2/4;
te_min = CN-4*c11;
Fmin = 10*log10(1+te_min);
%
np = [Fmin
      Rn
	  CN
     Gopt];
%
end