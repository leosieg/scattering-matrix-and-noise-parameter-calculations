function sp = sspi
%
% data input
% S parameters 
% EBC- or SGD-circuit or from two port of your choice
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% data out 
% S parameters for computation
%
% =========================================
%
% S parameter
% for example
% input from s2p-file, polar form
% Emitter circuit
% BFP640F, f = 1GHz, Uce = 1V, Ic = 5mA
s11 = 0.7086*exp((-62.2)*pi*1i/180);
s12 = 0.0599*exp((60.0)*pi*1i/180);
s21 = 11.304*exp((129.2)*pi*1i/180);
s22 = 0.7423*exp((-38.2)*pi*1i/180);
%
% =========================================
%
sp = [s11 s12
      s21 s22];
%
end