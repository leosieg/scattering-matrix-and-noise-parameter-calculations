function [soz,ctoz] = nsoz(s,ct,z)
%
% z impedance output series with noise
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% [soz,ctoz] = nsoz(s,ct,z)
%
%          s = S-parameters two port
%         ct = noise wave matrix two port
%          z = impedance output series
%
e1 = [1 1
      1 1];
%
% S matrix series z
sz = [z 2
      2 z]/(z+2);
%
% cascade
%
s1 = [s(1,1) 0
       0 sz(2,2)];
s2 = [s(1,2) 0
       0 sz(2,1)];
s3 = [sz(1,1) 1 
       1 s(2,2)];
s4 = [s(2,1) 0 
       0 sz(1,2)];
%
soz = s1+s2*s3*s4/(1-s(2,2)*sz(1,1));
%
% noise correlation matrix serie z
ctz = e1*(z+conj(z))/8;
%
% S -> T
e2 = [1 0
      0 1];
%
t1 = [s(1,1) s(1,2)
           1 0];
t2 = [      0 1 
       s(2,1) s(2,2)];
%
ts = t1*(t2\e2);
%
ctoz = ct+ts*ctz*ts';
%
end
