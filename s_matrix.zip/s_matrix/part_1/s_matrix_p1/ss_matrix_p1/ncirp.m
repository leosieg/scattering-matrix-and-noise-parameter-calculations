function ncirp(np,dsp,val,sw)
%
% noise circles with paraboloid
%
% Siegfried Martius
% siegfried.martius@fau.declose
% 202404
%
% ncirp(np,dsp,val,sw)
%
% np(1,1) = Fmin/dB
% np(2,1) = Rn/ohm
% np(3,1) = CN
% np(4,1) = Gopt
%     dsp = display paramter
%           'z' -> Smith chart z version
%			'y' -> Smith chart y version
%	  val =	noise circle F/Fmin difference/dB
%           example val = [0.5 1 1.5 2 2.5 3] 
%      sw = switch for display, 0 grid, 1 shaded
%
Fmin = np(1,1);
CN = np(3,1);
Gopt = np(4,1);
%
Si = 10^(0.1*Fmin)-1-CN*(1-(abs(Gopt))^2);
%
valsmith = [0 0.2 0.5 1 2 5];
%
% Smith chart z
if dsp == 'z' 
smith_z(valsmith) 
end
%
% Smith chart y
if dsp == 'y' 
smith_y(valsmith) 
end
%
hold on
%
% noise circles
Fu = np(1,1)+max(val);
Fn = length(val);
%
n_c=F_CIR(Fmin,CN,Gopt,Fu,Fn,180);
%                   
% dedicated noise figure
n_cf=F_G(Fmin,CN,Gopt,n_c); 
%
% noise circles display
contour(real(n_c),imag(n_c),n_cf,6,'-k','Linewidth',1);
% Octave
xlim([-1 1]);
ylim([-1 1]);
%
% choice of display
if sw == 1
     surf(real(n_c),imag(n_c),n_cf,'EdgeColor','none');
else
     mesh(real(n_c),imag(n_c),n_cf,abs(n_c));
end
%
% reflection coefficient for noise matching
plot3(real(Gopt),imag(Gopt),0,'+k','Linewidth',8)
%
h = text(real(Gopt),imag(Gopt),0,'\Gamma_{opt}',...
    'FontSize',14,'color','k','FontWeight','bold');
%	
set(h,'VerticalAlignment', 'bottom');
%
grid
zlabel('{\itF}/dB \rightarrow');
hold off
% Octave
view(3)
%
disp(['Schwarz inequality Si = ' num2str(Si,4)])
%
end