function [spy,ctpy] = nspy(s,ct,y)
%
% y admittance parallel feedback with noise
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
% 
% [spy,ctpy] = nspy(s,ct,y)
%
%        s = S-parameters two port
%       ct = noise wave matrix two port
%        y = admittance parallel feedback
%
e2 = [1 0
      0 1];
%
% S -> y
sy = (e2+s)\(e2-s);
%
% ct -> cy
mty = -[sy(1,1)+1 sy(1,1)-1
          sy(2,1) sy(2,1)];
%
cys = mty*ct*mty';
%
% y - matrix parallel y
yy = [1 -1 
     -1 1]*y;
%	  
% noise correlations matrix passive two port
cyy = (yy+yy')/2;
%
% parallel connection
yp = sy+yy;
cyp = cys+cyy;
%
% y -> S
spy = (e2+yp)\(e2-yp);
%
% cy -> ct
myt = -([yp(1,1)+1 yp(1,1)-1
           yp(2,1) yp(2,1)])\e2;
%
ctpy = myt*cyp*myt';
%
end
