% ===========================================================
% S- and noise parameters computation of simple electrical networks
% ===========================================================
% Siegfried Martius
% Lehrstuhl fuer Hochfrequenztechnik
% Friedrich Alexander University
% Erlangen-Nuernberg
% Cauerstrasse 9
% D-91058 Erlangen
% GERMANY
% 
% siegfried.martius@fau.de
% www.lhft.de
% ===========================================================
% 
% F_CIR.m      noise circles
% F_G.m        noise figure, G unequal Gopt
% jomegalc.m   nomalized impedance, admittance
% llpo.m       lossless line, parallel, end open
% llps.m       lossless line, parallel, end short
% llsl.m       lossless transmission line
% ncir.m       noise circles
% ncirp.m      noise circles with noise paraboloid
% ncnp.m       noise wave matrix -> noise parameters
% nnct.m       noise parameters -> noise wave matrix
% nnpi.m       noise data input from *.s2p file
% nscs.m       S-parameter cascade connection with noise
% nsiy.m       admittance y input parallel at two port with noise
% nsiz.m       impedance z input series at two port with noise
% nsoy.m       admittance y output parallel at two port with noise
% nsoz.m       impedance z output series at two port with noise
% nspp.m       two two ports parallel with noise
% nspy.m       admittance y parallel feedback with noise
% nssz.m       impedance z series feedback with noise
% smith_y.m    Smith chart y version
% smith_z.m    Smith chart z version
% sscs.m       S-parameter cascade connection
% ssiy.m       admittance y input parallel at two port
% ssiz.m       impedance z input series at two port
% sskl.m       Smith chart with load stability circle
% ssks.m       Smith chart with source stability circle
% ssoy.m       admittance y output parallel at two port
% ssoz.m       impedance z output series at two port
% sspi.m       S-paramters data input from *.s2p file
% sspp.m       two two ports parallel
% sspy.m       admittance y parallel feedback
% sspl_N.m     spline for data iteration signal and noise
% sspl_S.m     spline for data iteration signal only
% sssz.m       impedance z series feedback
% stnc_N.m     S-,T-,CT-matrices and noise parameters for the
%              EBC- or SGD-common circuits of transistor
% stnc_S.m     S-,T- matrices for the
%              EBC- or SGD-common circuits of transistor
% stot.m       S- -> T-matrix
% stra.m       ideal transformer
% ttos.m       T -> S-matrix
% 
% ===========================================================			 