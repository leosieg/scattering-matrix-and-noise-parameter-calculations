function [sszs,ctsz] = nssz(s,ct,z)
%
% z impedance series feedback with noise
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
% 
% [sszs,cts] = nssz(s,ct,z)
%
%        s = S-parameters two port
%       ct = noise wave matrix two port
%        z = impedance series feedback
%
e2 = [1 0
      0 1];
%
% S -> z
sz = (e2-s)\(e2+s);
%
% ct -> cz
mtz = [1+sz(1,1) 1-sz(1,1)
         sz(2,1) -sz(2,1)];
%
scz = mtz*ct*mtz';
%
% z - matrix parallel z
zz = [1 1
      1 1]*z;
%
% noise correlations matrix passive two port
zcz = (zz+zz')/2;
%
% seriell connection
ssz = sz+zz;
sscz = scz+zcz;
%
% z -> S
sszs = (ssz+e2)\(ssz-e2);
%
% cz -> ct
mzt = -([1+ssz(1,1) 1-ssz(1,1)
           ssz(2,1) -ssz(2,1)])\e2;
%
ctsz = mzt*sscz*mzt';
%
end