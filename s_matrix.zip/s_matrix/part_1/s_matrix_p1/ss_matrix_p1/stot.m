function tp = stot(s)
%
%  S matrix -> T matrix
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% tp = stot(s)
%
%  s = S matrix
%
e2 = [1 0
      0 1];
%
t1 = [s(1,1) s(1,2)
           1 0];
t2 = [      0 1 
       s(2,1) s(2,2)];
%
tp = t1*(t2\e2);
%
end