function [siz,ctiz] = nsiz(s,ct,z)
%
% z impedance input series with noise
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% [siz,ctiz] = nsiy(s,ct,z)
%
%          s = S-parameters two port
%         ct = noise wave matrix two port
%          z = impedance input series
%
e1 = [1 1
      1 1];
%
% S matrix series z
sz = [z 2
      2 z]/(z+2);
%
% cascade
%
s1 = [sz(1,1) 0
            0 s(2,2)];
s2 = [sz(1,2) 0
            0 s(2,1)];
s3 = [s(1,1) 1 
           1 sz(2,2)];
s4 = [sz(2,1) 0 
            0 s(1,2)];
%
siz = s1+s2*s3*s4/(1-sz(2,2)*s(1,1));	
%
% noise correlation matrix z
ctz = e1*(z+conj(z))/8;
%
% T matrix series z
tz = [2-z z
       -z 2+z]/2;
%
% cascade
ctiz = ctz+tz*ct*tz';
%
end
