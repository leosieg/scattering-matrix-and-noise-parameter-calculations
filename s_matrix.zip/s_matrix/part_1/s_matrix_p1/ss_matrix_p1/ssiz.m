function siz = ssiz(S,z)
%
% z impedance input series
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% siz = ssiz(s,z)
%
%   s = S-parameters two port
%   z = impedance input series
%
n = 2+z*(1-S(1,1));
%
siz11 = (z+4*S(1,1)/n)/(2+z);
siz12 = 2*S(1,2)/n;
siz21 = 2*S(2,1)/n;
siz22 = S(2,2)+z*S(1,2)*S(2,1)/n;
%
siz = [siz11 siz12
       siz21 siz22];
%
end