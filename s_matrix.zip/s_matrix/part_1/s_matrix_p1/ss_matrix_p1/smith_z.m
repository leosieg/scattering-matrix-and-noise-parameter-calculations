function smith_z(val)
%
% Smith chart, z version
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202403
% 
% smith_z(val)
%
%  val(array) = wanted circles, real and imaginary part
% example val = [0 0.2 0.5 1 2 5];
%
% point density
pk = 200/(2*pi);
phi = linspace(0,2*pi,pk*2*pi);
%
lv = length(val);
q = 1;
%
hold on
%
while q <= lv 
%
x0 = val(q)/(val(q)+1);
ra = 1/(val(q)+1);
%
z = x0 + ra*exp(1i*phi);
%
if ra == 1 || ra == 0.5
 plot(real(z),imag(z),'-r','LineWidth',2)
else
 plot(real(z),imag(z),'-r','LineWidth',1)
end
q = q+1;
%
end
%
% match circle z -> y g = 1
z = -0.5 + 0.5*exp(1i*phi);
plot(real(z),imag(z),'-m','LineWidth',1)
%
% circles constant -imaginary part
x0 = 1;
q = 2;
while q <= lv
%
y0 = 1/-val(q);
ra = 1/abs(val(q));
%
fis = pi/2;
fie = pi-acos(2*val(q)/(1+val(q)^2));
%
if abs(val(q)) > 1  
 fie = pi+acos(2*val(q)/(1+val(q)^2)); 
end
% 
phi = linspace(fis,fie,pk*abs(fie-fis));
z = x0+1i*y0+ra*exp(1i*phi);
%
plot(real(z),imag(z),'-b','LineWidth',1)
q = q+1;
%
end
%
% imaginary part constant circles
q = 2;
while q <= lv
y0 = 1/val(q);
ra = 1/abs(val(q));
%
fis = -acos(-2*val(q)/(1+val(q)^2));
if abs(val(q)) > 1  
 fis = -2*pi+acos(-2*val(q)/(1+val(q)^2)); 
end
fie = -pi/2;
%
phi = linspace(fis,fie,pk*abs(fie-fis));
z = x0+1i*y0+ra*exp(1i*phi);
% 
plot(real(z),imag(z),'-b','LineWidth',1)
q = q+1;
%
end
%
plot([-1 1],[0 0],'-b','LineWidth',2)
% axis equal
% axis off
%
q = 1;
%
while q <= lv
%
xq = (val(q)-1)/(val(q)+1)+0.02;
%
text(xq,0.05,num2str(val(q),1),'FontSize',12,'color','r','FontWeight','bold')
%
q = q+1;
end
%
q = 1;
%
while q <= lv
%
xq = (1i*val(q)-1)/(1i*val(q)+1);
phi = atan2(imag(xq),real(xq));
xp = real(xq);
yp = imag(xq);
%
h = text(xp,yp,['+j' num2str(val(q),1)],'FontSize',12,'color','b','FontWeight','bold');
%
set(h,'VerticalAlignment', 'bottom');
%
if xp == 0 
    set(h, 'Horizontalalignment', 'center');
elseif xp < 0
   set(h, 'Horizontalalignment', 'right');
else
   set(h, 'Horizontalalignment', 'left');  
end   
%
q = q+1;
end
%
q = 2;
%
while q <= lv
%
xq = (-1i*val(q)-1)/(-1i*val(q)+1);
phi = atan2(imag(xq),real(xq));
xp = real(xq);
yp = imag(xq);
%
h = text(xp,yp,['-j' num2str(val(q),1)],'FontSize',12,'color','b','FontWeight','bold');
%
set(h,'VerticalAlignment', 'top');
%
if xp == 0 
    set(h, 'Horizontalalignment', 'center');
elseif xp < 0
   set(h, 'Horizontalalignment', 'right');
else
   set(h, 'Horizontalalignment', 'left');  
end   
%
q = q+1;
end
%
hold off
end
