function st = stra(n)
%
% S matrix ideal transformer
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% st = tra(n)
%
%  n = n1/n2
%
nn = 1+n^2;
%
rho = (n^2-1)/nn;
tau = 2*n/nn;
%
st = [rho tau
      tau -rho];
%
end