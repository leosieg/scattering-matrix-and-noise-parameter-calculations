function siy = ssiy(S,y)
%
% y admittance input parallel
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% siy = ssiy(s,y)
%
%   s = S-parameters two port
%   y = admittance input parallel
%
n = 2+y*(1+S(1,1));
%
siy11 = (-y+4*S(1,1)/n)/(2+y);
siy12 = 2*S(1,2)/n;
siy21 = 2*S(2,1)/n;
siy22 = S(2,2)-y*S(1,2)*S(2,1)/n;
%
siy = [siy11 siy12
       siy21 siy22];
%
end