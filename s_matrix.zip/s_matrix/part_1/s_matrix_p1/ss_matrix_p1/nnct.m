function ct = nnct(np)
%
% noise parameters np -> noise matrix ct
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
%      ct = nnct(np)
%
%      ct = noise wave matrix
% np(1,1) = Fmin/dB
% np(2,1) = Rn/Ohm
% np(3,1) = CN
% np(4,1) = Gopt
%
Fmin = np(1,1);
Rn = np(2,1);
CN = np(3,1);
Gopt = np(4,1);
%
te_min = 10^(Fmin/10)-1;
%
ct11 = CN-te_min;
ct12 = CN*conj(Gopt);
ct22 = te_min+CN*abs(Gopt)^2;
%
ct = [ct11 ct12
conj(ct12) ct22]/4;
%
end