function spp = sspp(sx,sy)
%
% sx-sy parallel connection 
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% spp = sspp(sx,sy)
%
%  sx = S-parameters 1. two port
%  sy = S-parameters 2. two port
%
e2 =[1 0
     0 1];
%
y1 = (e2+sx)\(e2-sx);
y2 = (e2+sy)\(e2-sy);
y = y1+y2;
%
spp= (e2+y)\(e2-y);
%
end