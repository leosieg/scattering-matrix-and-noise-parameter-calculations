function [soy,ctoy] = nsoy(s,ct,y)
%
% y admittance output parallel with noise
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% [soy,ctoy] = nsoy(s,ct,y)
%
%          s = S-parameters two port
%         ct = noise wave matrix two port
%          y = admittance output parallel
%
e1 = [1 -1
     -1 1];
%
% S matrix parallel y
sy = [-y 2
       2 -y]/(y+2);
%
% cascade
%
s1 = [s(1,1) 0
           0 sy(2,2)];
s2 = [s(1,2) 0
           0 sy(2,1)];
s3 = [sy(1,1) 1 
            1 s(2,2)];
s4 = [s(2,1) 0 
           0 sy(1,2)];
%
soy = s1+s2*s3*s4/(1-s(2,2)*sy(1,1));	
%
% noise correlation matrix parallel y
cty = e1*(y+conj(y))/8;
%
% S -> T
e2 = [1 0
      0 1];
%
t1 = [s(1,1) s(1,2)
           1 0];
t2 = [      0 1 
       s(2,1) s(2,2)];
%
ts = t1*(t2\e2);
%
ctoy = ct+ts*cty*ts';
%
end
