function [spe,spb,spc,tpe,tpb,tpc] = stnc_S(s11,s12,s21,s22)
%
% or, if you have a FET
% function [sps,spg,spd,tps,tpg,tpd] = stnc_S(s11,s12,s21,s22)
%
% defining computation variables 
% for the three transistor basic circuits
% from common source/emitter data
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% S matrix source/emitter
sps = [s11 s12
       s21 s22];
%
% T matrix source/emitter
tps = stot(sps);
%
% emitter -> gate/base
ds = s11*s22-s12*s21;
n = -s11+s22+2*(s12+s21)+ds-5;
%
s11g = -(3*s11+s22+2*(s12+s21)+ds-1)/n;
s12g = -2*(s11-s22-2*s12-ds+1)/n;
s21g = -2*(s11-s22-2*s21-ds+1)/n;
s22g = -(s11+3*s22-2*(s12+s21)-ds+1)/n;
%
% S matrix gate/base
spg = [s11g s12g
       s21g s22g];
%
% T matrix gate/base
tpg = stot(spg);
%
% source -> drain
% emitter -> collector
%
ds = s11*s22-s12*s21;
n = s11-s22+2*(s12+s21)+ds-5;
%
s11d = -(3*s11+s22-2*(s12+s21)-ds+1)/n;
s12d = 2*(s11-s22+2*s12+ds-1)/n;
s21d = 2*(s11-s22+2*s21+ds-1)/n;
s22d = -(s11+3*s22+2*(s12+s21)+ds-1)/n;
%
% S matrix drain/collector
spd = [s11d s12d
       s21d s22d];
%
% T matrix drain/collector
tpd = stot(spd);
%
spe = sps;
spb = spg;
spc = spd;
tpe = tps;
tpb = tpg;
tpc = tpd;
%
end