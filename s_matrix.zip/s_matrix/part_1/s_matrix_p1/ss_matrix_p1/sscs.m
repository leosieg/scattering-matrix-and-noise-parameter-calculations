function scs = sscs(sx,sy)
%
% sx-sy cascade connection 
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% scs = sscs(sx,sy)
%
%  sx = S-parameters 1. two port
%  sy = S-parameters 2. two port
%
s1 = [sx(1,1) 0
            0 sy(2,2)];
s2 = [sx(1,2) 0
            0 sy(2,1)];
s3 = [sy(1,1) 1 
            1 sx(2,2)];
s4 = [sx(2,1) 0 
            0 sy(1,2)];
%
scs = s1+s2*s3*s4/(1-sx(2,2)*sy(1,1));
%
end