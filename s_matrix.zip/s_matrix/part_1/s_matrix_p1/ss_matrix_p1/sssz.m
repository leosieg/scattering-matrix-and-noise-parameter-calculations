function spz = sssz(s,z)
%
% z impedance series feedback
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
% 
% spz = sssz(s,ct,z)
%
%   s = S-parameters two port
%   z = impedance series feedback
%
s11 = s(1,1);
s12 = s(1,2);
s21 = s(2,1);
s22 = s(2,2);
%
n = 2+z*(2-(s11+s12+s21+s22));
ds = s11*s22-s12*s21;
%
sz11 =( 2*s11+z*(1-ds-s12-s21))/n;
sz12 = (2*s12+z*(1+ds-s11-s22))/n;
sz21 = (2*s21+z*(1+ds-s11-s22))/n;
sz22 = (2*s22+z*(1-ds-s12-s21))/n;
%
spz = [sz11 sz12
       sz21 sz22];
%
end