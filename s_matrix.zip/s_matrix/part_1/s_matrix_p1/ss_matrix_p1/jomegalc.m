function [jwl,jwc] = jomegalc(freq)
%
% normalized impedancs/admittances
% 
% Siegfried Martius
% siegfried.martius@fau.de
% 202404 
%
% [jwl,jwc] = jomegalc(freq)
%
%      freq = frequency/Hz
%
jwl = 1i*2*pi*freq/50;
jwc = 1i*2*pi*freq*50;
%
end