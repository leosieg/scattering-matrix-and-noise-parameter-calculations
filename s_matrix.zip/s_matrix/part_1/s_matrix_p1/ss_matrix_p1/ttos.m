function sp =  ttos(t)
%
%  T matrix -> S matrix
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% sp = ttos(t)
%
%  s = S matrix
%
e2 = [1 0
      0 1];
%	 
s1 = [t(1,1) t(1,2)
           0 1];
s2 = [t(2,1) t(2,2)
           1 0];
%
sp = s1*(s2\e2);
%
end