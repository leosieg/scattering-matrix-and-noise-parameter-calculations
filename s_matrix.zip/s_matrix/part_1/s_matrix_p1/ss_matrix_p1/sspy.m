function spy = sspy(S,y)
%
% y admittance parallel feedback 
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
% 
% spy = sspy(s,ct,y)
%
%   s = S-parameters two port
%   y = admittance parallel feedback
%
s11 = S(1,1);
s12 = S(1,2);
s21 = S(2,1);
s22 = S(2,2);
%
n = 2+y*(2+s11-s12-s21+s22);
ds = s11*s22-s12*s21;
%
sy11 = (2*s11-y*(1-ds-s12-s21))/n;
sy12 = (2*s12+y*(1+ds+s11+s22))/n;
sy21 = (2*s21+y*(1+ds+s11+s22))/n;
sy22 = (2*s22-y*(1-ds-s12-s21))/n;
%
spy = [sy11 sy12 
       sy21 sy22];
%
end