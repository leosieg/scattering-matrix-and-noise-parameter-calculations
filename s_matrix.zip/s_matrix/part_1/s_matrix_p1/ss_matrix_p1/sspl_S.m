function [s11,s12,s21,s22] = sspl_S(data_S,freq)
%
% data spline from txt(s2p) file for frequency analysis
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202403
% 
% [s11,s12,s21,s22] = sspl(data_S,freq)
%
%            data_S = string *.txt S-parameters file
%                     example 'BFP640F_S.txt'
%              freq = frequency/Hz
%
% units data txt(s2p) file
% freq/GHz mag(s11) ang(s11) mag(s21) ang(s21) mag(s12) ang(s12) mag(s22) ang(s22)
%
freq_N = length(freq);
%
% matrix adjustments
s11 = zeros(1,freq_N);
s12 = zeros(1,freq_N);
s21 = zeros(1,freq_N);
s22 = zeros(1,freq_N);
%
d_sp = zeros(freq_N,9);
%
% read S parameters
fiS = fopen(data_S,'r');
Sp = fscanf(fiS,'%f');
fclose(fiS);
%
spl = length(Sp);
d_S = zeros(spl/9,9);
%
% here freq from table
d_S(:,1) = Sp(1:9:spl-8)*1e9;
%
d_S(:,2) = Sp(2:9:spl-7);
d_S(:,3) = Sp(3:9:spl-6);
d_S(:,4) = Sp(4:9:spl-5);
d_S(:,5) = Sp(5:9:spl-4);
d_S(:,6) = Sp(6:9:spl-3);
d_S(:,7) = Sp(7:9:spl-2);
d_S(:,8) = Sp(8:9:spl-1);
d_S(:,9) = Sp(9:9:spl);
%
q = 2;
%
while q <= 9
%
d_sp(:,q) = spline(d_S(:,1),d_S(:,q),freq);
%
q = q+1;
end
%
s11 = d_sp(:,2).*exp(1i*d_sp(:,3)*pi/180);
s21 = d_sp(:,4).*exp(1i*d_sp(:,5)*pi/180);
s12 = d_sp(:,6).*exp(1i*d_sp(:,7)*pi/180);
s22 = d_sp(:,8).*exp(1i*d_sp(:,9)*pi/180);
%
end