function F = F_G(Fmin,CN,Gopt,G)
%
% noise figure for G unequal Gopt
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
%        F = F_G(Fmin,CN,Gopt,G)
%
%     Fmin = minimum noise figure/dB
%       CN = noise constant
%     Gopt = reflection coefficient for noise matching
% G(array) = current reflection coefficient 
%
h1 = 10^(0.1*Fmin);
h2 = CN*(abs(G-Gopt)).^2./(1-(abs(G)).^2+10*eps);
F = 10*log10(h1+h2);
end