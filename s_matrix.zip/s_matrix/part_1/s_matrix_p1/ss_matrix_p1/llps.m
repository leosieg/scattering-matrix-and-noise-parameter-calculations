function ys = llps(Zl,l,freq)
% 
% admittance ys
% lossless line parallel 
% end short
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
% 
%   ys = llps(Zl,l,freq)
%
%   Zl = characteristic impedance/Ohm
%    l = length/m
% freq = frequency/Hz
%
c0 = 2.99792458e8; 
ys = 50/(1i*Zl*tan(2*pi*freq*l/c0));
%
end