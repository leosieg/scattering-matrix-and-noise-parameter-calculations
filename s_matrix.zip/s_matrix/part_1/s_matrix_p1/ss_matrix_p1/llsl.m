function sl = llsl(Zl,l,freq)
% 
% S-parameters
% lossless line
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
%   sl = llsl(zl,l,freq)
% 
%   Zl = characteristic impedance/Ohm
%    l = length/m
% freq = frequency/Hz
%
c0 = 2.99792458e8;
bl = 2*pi*freq*l/c0;
g = (Zl/50-1)/(Zl/50+1);
%
n = 1-g*g*exp(-1i*2*bl);
%
rho = g*(1-exp(-1i*2*bl))/n;
tau = exp(-1i*bl)*(1-g*g)/n;
%
sl = [rho tau
      tau rho];
%
end