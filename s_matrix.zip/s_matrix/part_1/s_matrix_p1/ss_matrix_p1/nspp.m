function [spp,ctpp] = nspp(sx,ctx,sy,cty)
%
% sx-sy parallel connection with noise 
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% [spp,ctpp] = nspp(sx,ctx,sy,cty)
%
%         sx = S-parameters 1. two port
%        ctx = noise wave matrix 1. two port
%         sy = S-parameters 2. two port
%        cty = noise wave matrix 2. two port
%
e2 = [1 0
      0 1];
%
% S -> y
yx = (e2+sx)\(e2-sx);
yy = (e2+sy)\(e2-sy);
%
% y parallel
y = yx+yy;
%
% y -> S
spp= (e2+y)\(e2-y);
%
% ct -> cy
mty = -[yx(1,1)+1 yx(1,1)-1
          yx(2,1) yx(2,1)];
%		   
cyx = mty*ctx*mty';
%
mty = -[yy(1,1)+1 yy(1,1)-1
          yy(2,1) yy(2,1)];
%		  
cyy = mty*cty*mty';
%
cy = cyx+cyy;
%
% cy -> ct
myt = -[y(1,1)+1 y(1,1)-1
          y(2,1) y(2,1)]\e2;
%
ctpp = myt*cy*myt';
%
end
