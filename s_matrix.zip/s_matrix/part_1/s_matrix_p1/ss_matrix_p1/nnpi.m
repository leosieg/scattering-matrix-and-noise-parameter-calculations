function np = nnpi
%
% data input
% noise parameters 
% EBC- or SGD-circuit or from two port of your choice
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% data out 
% noise parameters for computation
%
% =====================================================
%
% example
% noise parameter
% input from s2p-file, polar form
% emitter circuit
% BFP640F, f = 1GHz, Uce = 1V, Ic = 5mA
Fmin = 0.55; % dB
Rn = 6; % Ohm
Gopt = 0.39*exp(1i*(21.3)*pi/180); % mag, ang/°
%
% ====================================================
%
CN = 4*Rn/(50*abs(1+Gopt)^2);
%
% Schwarz inequality
Si = 10^(0.1*Fmin)-1-CN*(1-(abs(Gopt))^2);
display(' ')
display(['Schwarz inequality Si = ' num2str(Si,2)]);
display(' ')
%
np = [Fmin
      Rn
	  CN
     Gopt];
%
end