function [siy,ctiy] = nsiy(s,ct,y)
% y admittance input parallel with noise
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% [siy,ctiy] = nsiy(s,ct,y)
%
%          s = S-parameters two port
%         ct = noise wave matrix two port
%          y = admittance input parallel
%
e1 = [1 -1
     -1 1];
%
% S matrix parallel y
sy = [-y 2
       2 -y]/(y+2);
%
% cascade
%
s1 = [sy(1,1) 0
            0 s(2,2)];
s2 = [sy(1,2) 0
            0 s(2,1)];
s3 = [s(1,1) 1 
           1 sy(2,2)];
s4 = [sy(2,1) 0 
            0 s(1,2)];
%
siy = s1+s2*s3*s4/(1-sy(2,2)*s(1,1));	   
%	   
% noise correlation matrix y parallel 
cty = e1*(y+conj(y))/8;
%
% T matrix y parallel
ty = [2-y -y
       y  2+y]/2;
%
% cascade
ctiy = cty+ty*ct*ty';
%
end
