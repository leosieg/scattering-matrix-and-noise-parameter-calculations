function soz = ssoz(S,z)
%
% z impedance output series
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% soz = ssoz(s,y)
%
%   s = S-parameters two port
%   z = impedance output series
%
n = 2+z*(1-S(2,2));
%
soz11 = S(1,1)+z*S(1,2)*S(2,1)/n;
soz12 = 2*S(1,2)/n;
soz21 = 2*S(2,1)/n;
soz22 = (z+4*S(2,2)/n)/(2+z);
%
soz = [soz11 soz12
       soz21 soz22];
%
end