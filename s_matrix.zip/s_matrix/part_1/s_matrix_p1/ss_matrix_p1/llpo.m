function yo = llpo(Zl,l,freq)
%
% admittance yo 
% lossless line parallel 
% end open
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
% 
%   yo = llpo(Zl,l,freq)
%
%   Zl = characteristic impedance/Ohm
%    l = length/m
% freq = frequency/Hz
%
c0 = 2.99792458e8;
yo = 1i*50*tan(2*pi*freq*l/c0)/Zl;
%
end