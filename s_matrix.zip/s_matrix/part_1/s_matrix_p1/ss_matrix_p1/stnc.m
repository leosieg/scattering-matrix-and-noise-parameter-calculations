function [spe,spb,spc,tpe,tpb,tpc,npe,npb,npc,cte,ctb,ctc,spo,cto] = stnc(s11,s12,s21,s22,Fmin,Rn,CN,Gopt)
%
% or, if you have a FET
% function [sps,spg,spd,tps,tpg,tpd,nps,npg,npd,cts,ctg,ctd,spo,cto] = stnc(s11,s12,s21,s22,Fmin,Rn,CN,Gopt)
%
% defining computation variables 
% for the three transistor basic circuits
% from common source/emitter data
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% S matrix source/emitter
sps = [s11 s12
       s21 s22];
%
% T matrix source/emitter
tps = stot(sps);
%
% noise parameter source/emitter
CN = 4*Rn/(50*abs(1+Gopt)^2);
nps = [real(Fmin)
       real(Rn)
	   real(CN)
	   Gopt];
%	
% ct matrix source/emitter
cts = nnct(nps);
%
% emitter -> gate/base
ds = s11*s22-s12*s21;
n = -s11+s22+2*(s12+s21)+ds-5;
%
s11g = -(3*s11+s22+2*(s12+s21)+ds-1)/n;
s12g = -2*(s11-s22-2*s12-ds+1)/n;
s21g = -2*(s11-s22-2*s21-ds+1)/n;
s22g = -(s11+3*s22-2*(s12+s21)-ds+1)/n;
%
% S matrix gate/base
spg = [s11g s12g
       s21g s22g];
%
% T matrix gate/base
tpg = stot(spg);
%
% source -> drain
% emitter -> collector
%
ds = s11*s22-s12*s21;
n = s11-s22+2*(s12+s21)+ds-5;
%
s11d = -(3*s11+s22-2*(s12+s21)-ds+1)/n;
s12d = 2*(s11-s22+2*s12+ds-1)/n;
s21d = 2*(s11-s22+2*s21+ds-1)/n;
s22d = -(s11+3*s22+2*(s12+s21)+ds-1)/n;
%
% S matrix drain/collector
spd = [s11d s12d
       s21d s22d];
%
% T matrix drain/collector
tpd = stot(spd);
%
% noise parameter conversion
te_min = 10^(Fmin/10)-1;
%
% source/emitter values
%
% pi - noise cicuit
Rnn = CN*abs(1+Gopt)^2/4;
Gnn = te_min*(1-abs(Gopt)^2-te_min/CN)/abs(1+Gopt)^2;
y_cor = (2*te_min/CN+(Gopt-1)*(conj(Gopt)+1))/abs(1+Gopt)^2;
%
% T - noise circuit
gnn = CN*abs(1-Gopt)^2/4;
rnn = te_min*(1-abs(Gopt)^2-te_min/CN)/abs(1-Gopt)^2;
z_cor = (2*te_min/CN+(Gopt+1)*(conj(Gopt)-1))/abs(1-Gopt)^2;
%
% source/emitter values -> gate/base
Rnn = 4*Rnn*abs(s21/(1+s11-2*s21-s22-ds))^2;
y_cor = y_cor*(1-(1+s11-s22-ds)/(2*s21))+((1-ds)^2-(s11-s22)^2-4*s12*s21)/...
              (2*s21*(1+s11+s22+ds));
%
w = sqrt(Gnn/Rnn+real(y_cor)^2);
CN = real(Rnn*((1+w)^2+imag(y_cor)^2));
Gopt = sqrt(((1-w)^2+imag(y_cor)^2)/((1+w)^2+imag(y_cor)^2));
%
x = 1-Gnn/Rnn-abs(y_cor)^2;
y = 2*imag(y_cor);
phi = atan2(y,x);
%
Gopt = Gopt*exp(j*phi);
%
Rn = 50*CN*abs(1+Gopt)^2/4;
Fmin = 10*log10(1+2*Rnn*(w+real(y_cor)));
%
% noise parameter gate/base
npg = [real(Fmin)
       real(Rn)
	   real(CN)
	   Gopt];
%
% ct matrix gate/base
ctg = nnct(npg);
%
% source/emitter values -> drain/collector
gnn = 4*gnn*abs(s21/(1-s11-2*s21+s22-ds))^2;
z_cor = z_cor*(1-(1-s11+s22-ds)/(2*s21))+((1-ds)^2-(s11-s22)^2-4*s12*s21)/...
              (2*s21*(1-s11-s22+ds));
%
w = sqrt(rnn/gnn+real(z_cor)^2);
CN = real(gnn*((1+w)^2+imag(z_cor)^2));
Gopt = sqrt(((1-w)^2+imag(z_cor)^2)/((1+w)^2+imag(z_cor)^2));
%
x = -1+rnn/gnn+abs(z_cor)^2;
y = -2*imag(z_cor);
phi = atan2(y,x);
%
Gopt = Gopt*exp(j*phi);
%
Rn = 50*CN*abs(1+Gopt)^2/4;
Fmin = 10*log10(1+2*gnn*(w+real(z_cor)));
%
% noise parameter drain/collector
npd = [real(Fmin)
       real(Rn)
	   real(CN)
	   Gopt];
%
% ct matrix drain/collector
ctd = nnct(npd);
%
% special S matrix for through
spo = [0 1
       1 0];
%
% special noise wave matrix
% for lossless two port	   
cto = [0 0
       0 0];
%
% if you have a FET stop here
%
spe = sps;
spb = spg;
spc = spd;
tpe = tps;
tpb = tpg;
tpc = tpd;
cte = cts;
ctb = ctg;
ctc = ctd;
npe = nps;
npb = npg;
npc = npd;
%
end