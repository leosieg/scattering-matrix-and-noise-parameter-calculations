function soy = ssoy(S,y)
%
% y admittance output parallel
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% soy = ssoy(s,y)
%
%   s = S-parameters two port
%   y = admittance output parallel
%
n = 2+y*(1+S(2,2));
%
soy11 = S(1,1)-y*S(1,2)*S(2,1)/n;
soy12 = 2*S(1,2)/n;
soy21 = 2*S(2,1)/n;
soy22 = (-y+4*S(2,2)/n)/(2+y);
%
soy = [soy11 soy12
       soy21 soy22];
%
end