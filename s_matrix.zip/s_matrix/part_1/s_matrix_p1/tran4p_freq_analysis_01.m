% four transistors frequency analysis
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202404
%
% clear workspace, adjustments 
clear all
close all
set(0,'DefaultLineLineWidth',4);
set(0,'DefaultAxesFontSize',14);
set(0,'DefaultTextFontSize',14);
set(0,'DefaultAxesClipping','on');
%
% adjustments
scsz = get(0,'ScreenSize');
pos1 = [0.75*scsz(3),0.64*scsz(4),0.25*scsz(3),0.3*scsz(4)];
dfig = -30;
%
% bandpass analysis
freq = [0.9:0.001:1.1]*1e9;
%
tic
% ======================================================== 
%
[s11,s12,s21,s22,Fmin,Rn,CN,Gopt] = tran4p_circuit_01(freq);
%
% ========================================================
toc
%
% noise figure Gamma = 0
F50 = 10*log10(10.^(0.1*Fmin)+CN.*abs(Gopt).^2);
%
ds = s11.*s22-s12.*s21;
%
mu1 = (1-abs(s11).^2)./(abs(s22-conj(s11).*ds)+abs(s12.*s21));
mu2 = (1-abs(s22).^2)./(abs(s11-conj(s22).*ds)+abs(s12.*s21));
%
% find index for freq ca. 1 GHz
[m,i] = min(abs(freq-1e9));
%
sp = [s11(i) s12(i)
      s21(i) s22(i)];
%
np = [Fmin(i)
       Rn(i)
       CN(i)
       Gopt(i)];
% ========================================================
% --------------------------------------------------------
nfig = 1;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s21)))
axis([min(freq)/1e9 max(freq)/1e9 10 20])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{21}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 2;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s11)))
axis([min(freq)/1e9 max(freq)/1e9 -10 -0])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{11}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 3;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,20*log10(abs(s22)))
axis([min(freq)/1e9 max(freq)/1e9 -10 0])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('|s_{22}|^2/dB \rightarrow')
% --------------------------------------------------------
nfig = 4;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,mu1,freq/1e9,mu2)
axis([min(freq)/1e9 max(freq)/1e9 0 2])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('\mu_1,\mu_2 \rightarrow')
% --------------------------------------------------------
nfig = 5;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
ssks(sp,'z')
% --------------------------------------------------------
nfig = 6;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
sskl(sp,'y')
%
% --------------------------------------------------------
nfig = 7;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
plot(freq/1e9,Fmin,'-r',freq/1e9,F50,'-b')
axis([min(freq)/1e9 max(freq)/1e9 0 1])
grid
xlabel('frequency/GHz \rightarrow')
ylabel('F/dB \rightarrow')
%
legend('F_{min}','F_{\Gamma=0}','Location','SouthEast')
legend('boxoff')
% --------------------------------------------------------
nfig = 8;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
valnc = [0:0.5:3];
ncir(np,'z',valnc)
% --------------------------------------------------------
nfig = 9;
figure(nfig)
clf
set(gcf,'Position',pos1+[0 (nfig-1)*dfig 0 0]);
set(gcf,'color','white')
hold off
%
valnc = [0:0.1:3];
ncirp(np,'y',valnc,1)
%
% plot without white border
%exportgraphics(gcf, './noise_01.png',...
%               'BackgroundColor','none','ContentType','vector') 
%


