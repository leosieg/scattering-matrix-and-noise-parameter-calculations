function [rs11,rs12,rs21,rs22,rFmin,rRn,rCN,rGopt] = tran4p_circuit_01(freq)
%
% four transistors parallel circuit analysis with noise
%
% Siegfried Martius
% siegfried.martius@fau.de
% 202403
%
% freq/Hz
%
[s11,s12,s21,s22,Fmin,Rn,CN,Gopt] = sspl_N('BFP640F_S.txt','BFP640F_N.txt',freq);
%	   
freq_q = length(freq);
%
rs11 = zeros(1,freq_q);
rs12 = zeros(1,freq_q);
rs21 = zeros(1,freq_q);
rs22 = zeros(1,freq_q);
%
rFmin = zeros(1,freq_q);
rRn = zeros(1,freq_q);
rCN = zeros(1,freq_q);
rGopt = zeros(1,freq_q);
%
q = 1;
%
while q <= freq_q
%
sp = [s11(q) s12(q)
      s21(q) s22(q)];
%
np = [Fmin(q)
      Rn(q)
      CN(q)
      Gopt(q)];
%
ct = nnct(np);
%
% ===== topology transistor parallel =====
%
% two transistors parallel
[rsp,rct] = nspp(sp,ct,sp,ct);
%
% three transistors parallel
[rsp,rct] = nspp(rsp,rct,sp,ct);
%
% four transistors parallel
[rsp,rct] = nspp(rsp,rct,sp,ct);
%
% =============================
%
rs11(q) = rsp(1,1);
rs12(q) = rsp(1,2);
rs21(q) = rsp(2,1);
rs22(q) = rsp(2,2);
%
np = ncnp(rct);
%
rFmin(q) = real(np(1,1));
rRn(q) = real(np(2,1));
rCN(q) = real(np(3,1));
rGopt(q) = np(4,1);
%
q = q+1;
%	  
end
end